# MVP Implementation Plan: Simple Android Text Editor

## Context
The goal is to implement a professional-grade text editor for Android 11+ (API 30+). The project is being built from scratch using a "Pure Java and XML" stack, replacing the previous Kotlin/Compose design. The focus is on providing a desktop-like experience on mobile, featuring SAF integration, a two-row horizontal split view, and advanced text manipulation.

## Recommended Approach

### 1. Project Setup & Architecture
- **Architecture**: MVVM using `androidx.lifecycle` (ViewModel, LiveData).
- **UI**: Android View system with XML layouts.
- **Structure**:
    - `data.saf`: SAF wrappers for file I/O.
    - `data.repository`: File state and content management.
    - `ui.editor`: Editor logic, custom views for zoom/diff.
    - `ui.main`: Tab orchestration and main navigation.
    - `model`: `Document` and `AppState` POJOs.

### 2. Implementation Phases

#### Phase 1: Foundation (Basic Editing)
- **SAF Manager**: Implement `SAFManager.java` to handle `ACTION_OPEN_DOCUMENT` and `takePersistableUriPermission`.
- **Editor Core**: Create `EditorFragment` and `fragment_editor.xml` with an `EditText`.
- **State Logic**: Implement `EditorViewModel` to track the "dirty" state and enforce "save before switch" for Read Mode.

#### Phase 2: Tab Management & Navigation
- **Tab Orchestration**: Use `MainViewModel` to manage a list of open `Document` objects.
- **Looping Navigation**: Integrate `ViewPager2` for horizontal swiping. Implement modulo indexing for continuous looping.
- **Navigation**: Build the Hamburger menu using `DrawerLayout` for file operations.

#### Phase 3: Advanced View Modes
- **Horizontal Split View**: Create a vertical `LinearLayout` layout that dynamically hosts two `EditorFragment` instances in two rows.
- **Diff View**: Implement a vertical comparison UI with two synchronized `ScrollView`s. Use a custom diffing algorithm with `Spannable` text for highlighting changes (red/green).

#### Phase 4: Polish & Typography
- **Pinch-to-Zoom**: Implement `ScaleGestureDetector` in the editor to adjust `textSize` between 8sp and 72sp.
- **UI Refinement**: Finalize XML styles and ensure API 30+ compatibility.

## Critical Files
- `app/src/main/java/com/example/texteditor/data/saf/SAFManager.java`
- `app/src/main/java/com/example/texteditor/ui/editor/EditorViewModel.java`
- `app/src/main/java/com/example/texteditor/ui/editor/EditorFragment.java`
- `app/src/main/res/layout/fragment_editor.xml`
- `app/src/main/java/com/example/texteditor/model/Document.java`

## Verification Plan
- **File I/O**: Open a file $\rightarrow$ edit $\rightarrow$ save $\rightarrow$ verify content on disk.
- **State Safety**: Edit a file $\rightarrow$ attempt to switch to Read Mode $\rightarrow$ verify "Save changes?" prompt.
- **Tab Loop**: Open 3 files $\rightarrow$ swipe through all $\rightarrow$ verify it loops back to the first.
- **Split View**: Toggle Split View $\rightarrow$ verify two editors appear in two distinct rows.
- **Diff View**: Load two different files $\rightarrow$ enable Diff Mode $\rightarrow$ verify red/green highlights.
- **Zoom**: Use pinch gesture $\rightarrow$ verify font size scales between 8sp and 72sp.
