# Final Fix Plan — Simple Android Text Editor

## Overview
This document is the final, ordered fix plan for the Simple Android Text Editor project (Java + XML, API 30+). It consolidates critical bug fixes, UI improvements, and feature adjustments into a prioritized implementation and verification plan.

## Implementation Order (Recommended)
1 → 2 → 3 → 8 → 4 → 5 → 6 → 7 → 9 → 10

---

## Phase 1: Critical Bug Fixes (Must Fix First)

### 1. Fix DiffEditorView Crash (CRITICAL)
- Location: app/src/main/java/com/example/texteditor/ui/editor/DiffEditorView.java  
- Problem: Constructor calls init() which uses findViewById(), but R.layout.view_split_editor is not inflated → NPE.  
- Fix: Inflate R.layout.view_split_editor into this before calling findViewById() in init().  
- Verification:
  - Launch Diff View without crash.
  - setDocuments() executes without NPE.

### 2. Fix EditorFragment: Read Mode Behavior (HIGH)
- Location: app/src/main/java/com/example/texteditor/ui/editor/EditorFragment.java  
- Problem: Read mode disables EditText entirely — blocks scroll/select/copy and prevents non-keyboard interactions.  
- Fix:
  - Read mode: keep EditText enabled for selection/scrolling but disable text input (e.g., setInputType(EditorInfo.TYPE_NULL) or setFocusable(false) + setFocusableInTouchMode(false)).
  - Write mode: restore normal input type and setFocusableInTouchMode(true).
  - Remove any forced showSoftInput(); rely on natural focus to show keyboard.  
- Verification:
  - In Read mode: can scroll, select, copy; tapping does not show keyboard.
  - In Write mode: can edit; keyboard appears when focusing.

### 3. Fix Mode Toggle Not Updating Immediately (HIGH)
- Location: MainActivity.java, MainViewModel.java, EditorFragment.java  
- Problem: Toggling Document.mode doesn't update EditorFragment until tab is reselected.  
- Fix:
  - Add refreshDocuments() in MainViewModel that re-emits openDocuments (openDocuments.setValue(docs)).
  - Call mainViewModel.refreshDocuments() after toggling mode in MainActivity.toggleMode().  
- Verification:
  - Toggle mode updates editor UI immediately for active tab.

---

## Phase 2: UI Improvements & Medium Priority Fixes

### 4. Fix Font Size Only Having 2 Values (MEDIUM)
- Location: app/src/main/java/com/example/texteditor/ui/editor/ZoomEditText.java, EditorFragment.java  
- Problem: ZoomEditText.init() hardcodes setTextSize(14f), conflicting with ViewModel/XML initial sizes and pinch zoom.  
- Fix:
  - Remove hardcoded setTextSize(14f) in ZoomEditText.init().
  - Initialize font size from XML attributes or ViewModel.
  - Ensure pinch-zoom updates a single source-of-truth size used by EditorFragment and persisted if relevant.  
- Verification:
  - Default font respects setting; pinch zoom and menu controls produce smooth, continuous values within 8–72sp.

### 5. Remove "Split View" from Menu (LOW)
- Location: app/src/main/res/layout/nav_menu_content.xml  
- Problem: Unimplemented Split View menu item confuses users.  
- Fix: Remove the <TextView android:id="@+id/menu_split"...> entry from nav_menu_content.xml.  
- Verification:
  - Menu no longer shows Split View entry; layout compiles and displays correctly.

### 6. Fix "X" Close Button Style (MEDIUM)
- Location: MainActivity.java - updateOpenFilesList()  
- Problem: Close button uses Button with default background and inconsistent sizing.  
- Fix:
  - Replace with a TextView styled as a clean "X" (no background, centered, matching height).
  - Ensure accessibility (contentDescription) and touch target size.  
- Verification:
  - Drawer shows tidy close icons; closing behavior unchanged; dirty-file blocking still enforced.

### 7. Title Ellipsis & Toggle Full Path on Tap (LOW)
- Location: app/src/main/res/layout/activity_main.xml, MainActivity.java  
- Problem: Long filenames break layout or appear awkwardly truncated.  
- Fix:
  - Add to tv_title:
    - android:ellipsize="end"
    - android:maxLines="1"
    - android:singleLine="true"
  - Implement click listener to toggle between filename-only and full path display.  
- Verification:
  - Long filenames show ellipsis by default; tapping toggles full path display.

### 8. Move Font +/- to Collapsible Settings Section (LOW)
- Location: nav_menu_content.xml, MainActivity.java  
- Problem: Font controls clutter the main menu.  
- Fix:
  - Group font controls under an expandable/collapsible "Settings" header or hide by default and reveal on settings tap.  
- Verification:
  - Font controls accessible under Settings; menu layout remains compact.

### 9. Fix Save Logic — Display Filename After Save (MEDIUM)
- Location: MainActivity.java - handleSaveAs()  
- Problem: After Save As, setFilename(uri.getPath()) shows full document tree path.  
- Fix:
  - Use ContentResolver.query() with DocumentsContract.Document.COLUMN_DISPLAY_NAME to extract the display filename.
  - Set document filename to that display name.  
- Verification:
  - After Save/Save As, UI shows only the filename (e.g., "notes.txt"), not the full tree path.

### 10. Diff View: File Selection Dialog for Two Files (MEDIUM)
- Location: MainActivity.java - showDiffView()  
- Problem: Diff view currently picks the first two open files or requires both to be open.  
- Fix:
  - Implement a dialog to select two files from open documents (with option to open files if fewer than two).
  - Alternatively, allow ACTION_OPEN_DOCUMENT twice to explicitly pick files for diff.  
- Verification:
  - Diff view opens with chosen file pair and highlights differences correctly.

---

## Phase 3: File Management, Tabs & Integrity

### 11. Unique Untitled Names
- Location: MainViewModel.java  
- Fix: Implement untitled counter producing untitled_01.txt, untitled_02.txt, etc.  
- Verification:
  - New files get unique untitled names; names persist until saved.

### 12. Close Files — "X" Behavior & Dirty Blocking
- Location: MainActivity.java, MainViewModel.java  
- Fix:
  - "X" buttons trigger close logic in MainViewModel.
  - Block closing dirty files; prompt "Save changes?" if attempting to close.  
- Verification:
  - Closing non-dirty files removes tab; dirty files prompt and block until saved or user discards changes.

### 13. Tab Navigation Integrity
- Location: EditorPagerAdapter.java, MainViewModel.java  
- Fix:
  - Ensure EditorPagerAdapter maps one Document ↔ one Fragment consistently.
  - Verify Drawer taps call switchTab(index) and ViewPager index updates accordingly.  
- Verification:
  - Drawer tap switches to correct tab; swipes and programmatic switches keep mapping intact.

### 14. Tab Looping (ViewPager2)
- Location: MainActivity.java, MainViewModel.java  
- Fix: Ensure modulo indexing for ViewPager2 adapter or adapter-level position mapping to enable continuous loop.  
- Verification:
  - Swiping forward from last tab loops to first; backward from first loops to last.

---

## Phase 4: Diff View & Split View Refinement

### 15. Swap Top/Bottom in Diff View
- Location: R.layout.view_split_editor, DiffEditorView.java  
- Fix:
  - Add "Swap Top/Bottom" button to view_split_editor.
  - Implement swap logic in DiffEditorView to exchange documents and re-run diff highlighting.  
- Verification:
  - Swap button switches top/bottom editors and preserves modes and scroll sync.

### 16. updateModes() in DiffEditorView
- Location: DiffEditorView.java  
- Fix:
  - Implement updateModes() to allow WRITE mode for the top editor and enforce READ for bottom (or as configured).
  - Ensure UI toggles and ViewModel stay in sync.  
- Verification:
  - Mode updates apply immediately; write permission reflects in top editor.

---

## Phase 5: Logging, Crash Investigation & Misc

### 17. App Log System & log_data.txt
- Location: app/src/main/java/... (new logging subsystem)  
- Fix:
  - Implement global logger capturing app events and uncaught exceptions.
  - Maintain log_data.txt as the last item in file list; update it in real-time.
  - Allow saving/exporting log_data.txt via SAF like other documents.  
- Verification:
  - Logger records events; log_data.txt updates; file can be opened/saved.

### 18. Use Logs to Investigate Crash 1 (SAFManager/MainActivity)
- Location: SAFManager.java, MainActivity.java  
- Fix:
  - Integrate logging calls at critical SAF operations and file I/O entry/exit.
  - Reproduce prior crash, inspect logs, and patch root cause (if different from DiffEditorView).  
- Verification:
  - Crash traces appear in log; root cause fixed; no regression in file I/O.

### 19. Top Menu Title Binding (Bug 3)
- Location: MainActivity.java  
- Fix:
  - Observe currentTabIndex and set tv_title to current document filename.
  - Ensure title updates on tab switch and after Save As.  
- Verification:
  - Title matches current tab filename and updates promptly.

### 20. Line Numbers — Scroll Sync
- Location: EditorFragment.java, layout files  
- Fix:
  - Sync rv_line_numbers scroll with ZoomEditText vertical scroll events.
  - Update line numbers on text change and ensure performance for large files.  
- Verification:
  - Line numbers follow editor scroll and update correctly.

### 21. Typography Settings & Bottom Info Bar
- Location: EditorFragment.java, activity_main.xml  
- Fix:
  - Add settings to adjust default font size and style; persist in ViewModel/preferences.
  - Add bottom info bar showing cursor line/col and total tab count.  
- Verification:
  - Settings applied and persisted; bottom bar shows accurate info.

---

## Verification Checklist (Post-implementation)
For each implemented fix:
- [ ] Specific issue resolved (manual test).
- [ ] No regressions in related features (smoke tests).
- [ ] UI validated on multiple screen sizes and orientations.
- [ ] Confirm API 30+ compatibility.
- [ ] Run end-to-end file open → edit → save → reopen flows.

Suggested final regression test flows:
- Open/save flow with SAF (external storage, Drive).
- Edit → attempt to switch to Read mode with dirty file → verify "Save before switch" block.
- Open 3+ tabs → verify swipe looping and drawer tab selection.
- Toggle Read/Write modes and verify immediate UI updates.
- Diff view file selection, swap, and highlighting.
- Pinch-to-zoom, font menu adjustments, and persisted font defaults.

---

## Notes & Constraints
- Maintain MVVM pattern and LiveData observer conventions.
- Avoid adding new external dependencies unless essential.
- Keep compatibility with API 30+.
- Preserve one-to-one Document ↔ Fragment mapping.
- No code shown here per request; this plan is for implementation guidance and PR preparation.

---

End of Fix Plan.