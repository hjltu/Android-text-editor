# Project Specification: Simple Android Text Editor

## 1. Overview
A professional-grade, lightweight text editor for Android focusing on productivity and stability for developers and power users. It emphasizes a "desktop-like" experience on mobile, utilizing the Storage Access Framework (SAF) for secure file management.

## 2. Technical Stack
- **Language**: Pure Java
- **UI Framework**: Android XML Layouts (View-based system)
- **Architecture**: MVVM (Model-View-ViewModel)
- **Target Platform**: Android 11+ (API Level 30+)
- **State Management**: Java-based state management (e.g., LiveData, ViewModel)
- **File System Access**: Storage Access Framework (SAF)

## 3. Functional Requirements

### 3.1 File Management & Access
- **SAF Integration**: Seamless opening and saving of files from any supported location via Android's Storage Access Framework.
- **Tab Management**: Support for multiple open files.
- **Quick Cycle**: Implementation of horizontal swipe gestures to cycle through open tabs in a continuous loop.

### 3.2 Editing Capabilities
- **Read Mode**: View-only mode optimized to prevent accidental edits.
- **Edit Mode**: Full text editing capabilities.
- **State Safety**: The application must block transitions from Edit Mode to Read Mode if the file has unsaved changes (dirty state).

### 3.3 Advanced View Modes
- **Diff View**: A **two-row layout**  where two editors are displayed vertically (one on top of the other),comparison tool using a custom diffing algorithm to highlight additions and deletions between two selected files.

### 3.4 Typography & Accessibility
- **Pinch-to-Zoom**: Dynamic font size adjustment via intuitive pinch gestures.
- **Font Range**: Support for font sizes ranging from 8sp to 72sp.

## 4. User Interface (UI) Requirements
- **Navigation**: Hamburger menu (top-left) for:
    - Opening files
    - Enabling Diff Mode
- **Tab Interaction**: Horizontal swiping across the editor area to switch files.
- **Mode Control**: Status bar or menu toggles for switching between Read and Edit modes.
- **Visual Feedback**: Clear highlighting of differences in Diff View.

## 5. Constraints & Safety
- **API Level**: Must maintain compatibility with API 30+.
- **Data Integrity**: Strict enforcement of "save before switch" when moving from Edit to Read mode.
