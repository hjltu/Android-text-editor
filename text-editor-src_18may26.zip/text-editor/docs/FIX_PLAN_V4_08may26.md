# Text Editor Enhancements — Implementation Plan (Reviewed)

## Rules (project/workflow)
- Project dir: text editor.  
- No git operations.  
- If you encounter "Error editing file" — stop and wait for user input.  
- Before editing a file: re-read it (cat), ensure cache/update, show the diff of proposed changes, and wait for user confirmation.  
- Do not run builds automatically; wait for explicit instruction to build.  
- Environment: Java · Android 11+ (assumed).  
- Senior-level expectations: concise, test-driven, and safe edits that respect existing realizations (avoid blind code insertion).

## Build notice
- When project is ready to build do not try to build automatically — builds are performed manually. Wait for further instruction before invoking any build or CI step.

---

## Summary (tasks)
- Add build number header (ddMMMyy) to first line of log_data.txt  
- Line numbers: tap-to-goto-line  
- Make line-numbers the authoritative scroller; disable direct vertical scrolling in text area  
- Fix line-number ↔ text mismatch (choose physical or visual line policy)  
- Add line-number area in Diff Mode (both panes)  
- Enable copy in Read Mode without bringing up keyboard  
- Bottom info bar: show current (live) cursor line/col, not last position  
- Settings submenu: add "About" with build number  
- Make navigation/menu view scrollable  
- Show/hide line number area (toggle, persisted)

### Ordered Implementation (recommended)
1 → 4 → 3 → 2 → 5 → 6 → 7 → 8 → 9 → 10

Rationale: fix line-count correctness first, then scrolling model, then interaction features, then UI extras; finalize visibility toggle last.

---

## Per-task Plan (concise)

### Task 1 — Build number header in log_data.txt (ddMMMyy)
- Source build id from BuildConfig or injected build-time var.  
- Format date ddMMMyy (e.g., 08May26).  
- Prepend `Build: <ddMMMyy>` as first line on logger init and on export/save.  
- Verification: log_data.txt first line matches build.

### Task 2 — Fix line-number ↔ text mismatch (policy decision)
- Choose Option A (physical: count '\n') or Option B (visual: Layout.getLineCount()) and apply consistently.  
- If visual chosen, generate line numbers after layout pass (post/OnGlobalLayoutListener).  
- Verification: line numbers match chosen policy.

### Task 3 — Make line-numbers control scrolling; disable text-area vertical scroll
- Make gutter view primary vertical scroller (RecyclerView/NestedScrollView).  
- Disable vertical touch scrolling in EditText (consume or set non-scrollable vertically).  
- On gutter scroll, compute offset and programmatically scroll editor (Layout.getLineTop / scrollTo).  
- Verification: gutter scroll moves text; text-area vertical scroll disabled.

### Task 4 — Line-number tap → goto line
- Make gutter items clickable.  
- On tap compute target line index and offset via Layout or line-start mapping.  
- Scroll editor to that line and move caret:
  - WRITE: setSelection(offset) and focus if further editing.
  - READ: setSelection without showing keyboard (showSoftInputOnFocus=false).
- Clamp out-of-range taps to last line.  
- Verification: tap navigates and places caret; keyboard suppressed in read mode.

### Task 5 — Add line-number area in Diff Mode
- Add gutter columns for both panes in split/diff layout.  
- Reuse line-generation and tap logic per pane.  
- Sync each pane’s gutter scroll with its editor; preserve mappings on swap.  
- Verification: both diff panes show line numbers and remain synced.

### Task 6 — Copy text in Read Mode without keyboard
- Configure read-mode editor:
  - setTextIsSelectable(true)
  - setShowSoftInputOnFocus(false)
  - keep longClickable/contextual menu enabled
- Optionally add explicit Copy action if platform suppresses menu.  
- Verification: select & copy without keyboard appearing.

### Task 7 — Bottom info bar: live cursor line/col
- Update on selection change, text change, and programmatic caret moves.  
- Compute line via Layout.getLineForOffset(selectionStart) and column as offset − getLineStart(line).  
- Debounce if necessary.  
- Verification: bottom bar updates live for cursor moves.

### Task 8 — Settings → About with build number
- Add About entry under Settings.  
- Dialog shows app name, author ("hjltu"), versionName/versionCode and build id/date used in logs.  
- Verification: About displays correct build info.

### Task 9 — Make menu/drawer scrollable
- Wrap menu content in RecyclerView or NestedScrollView to handle overflow.  
- Ensure controls remain accessible while scrolling.  
- Verification: drawer scrolls when items overflow.

### Task 10 — Show/Hide Line Number Area (short)
- UI: Settings toggle (pref_show_line_numbers) + toolbar button.  
- Persistence: SharedPreferences boolean (default true).  
- Runtime: EditorFragment.setLineNumbersVisible(boolean)
  - set gutter view VISIBLE/GONE, adjust editor padding/layout.
  - attach/detach gutter scroll listener.
  - when gutter hidden: enable editor vertical scrolling; when shown: disable editor vertical scroll (per authoritative-scroller policy).
  - call updateLineNumberGeneration() and updateBottomInfoBar() after layout pass.
- Edge cases: use RecyclerView for large files, debounce layout changes, preserve caret.  
- Verification: toggle persists and behaves properly in single and diff modes.

---

## Integration & Edge Cases (high level)
- Always wait for layout completion before using EditText.getLayout() — use post or OnGlobalLayoutListener.  
- For large files, avoid per-character heavy work during scroll; use RecyclerView + lazy/virtualized gutter.  
- Keep read-mode selection from triggering keyboard (showSoftInputOnFocus=false, avoid requestFocus()).  
- Ensure diff-mode keeps parity with single-editor features and preserved listeners across swaps.  
- If toggling while animations or long ops run, cancel/finish animations before layout changes.

---

## Verification Checklist (post-implementation)
- log_data.txt first line = Build: ddMMMyy  
- Line numbers align with chosen policy (physical or visual)  
- Tapping line numbers navigates correctly; caret/selection updated  
- Vertical scrolling works only via line-number pane (text-area vertical scroll disabled when gutter authoritative)  
- Diff mode displays line numbers in both panes and syncs correctly  
- Read Mode copy works without keyboard  
- Bottom info bar shows live cursor line/col  
- Settings → About displays build number  
- Drawer/menu scrolls when items overflow  
- Show/hide gutter toggle persists and behaves as specified

---
