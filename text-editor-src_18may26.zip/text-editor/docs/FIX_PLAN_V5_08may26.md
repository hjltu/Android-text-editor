# Text Editor Enhancements — Implementation Plan (Reviewed)

## Rules (project/workflow)
- Project dir: text editor.  
- No git operations.  
- If you encounter "Error editing file" — stop and wait for user input.  
- Before editing a file: re-read it (cat), ensure cache/update, show the diff of proposed changes, and wait for user confirmation.  
- Do not run builds automatically; wait for explicit instruction to build.  
- Environment: Java · Android 11+ (assumed).  
- Senior-level expectations: concise, test-driven, and safe edits that respect existing realizations (avoid blind code insertion).

## Build notice
- Builds are manual. After completing each stage below run a full checkup and only build when you confirm — do not build automatically.

---

# Stage 1 — Core correctness & scrolling model

Purpose: fix line-count correctness and establish the authoritative scrolling model before adding interaction/UI features.

Tasks (Stage 1)
1. Add build number header in log_data.txt (ddMMMyy)  
2. Fix line-number ↔ text mismatch (choose physical or visual line policy)  
3. Make line-numbers control scrolling; disable text-area vertical scroll  
4. Line-number tap → goto line

Per-task summary (Stage 1)
- Task 1: Prepend `Build: ddMMMyy` on logger init/export (verify log_data.txt).  
- Task 2: Decide Option A (physical) or Option B (visual); implement consistently; run generation after layout if visual.  
- Task 3: Make gutter the primary scroller (RecyclerView/NestedScrollView); disable EditText vertical scroll; sync gutter scroll to editor.  
- Task 4: Make gutter items clickable; map taps to line offsets; scroll and set caret; suppress keyboard in read mode.

Stage 1 Integration & Edge Cases
- Always wait for layout completion before using EditText.getLayout().  
- For large files, avoid per-character heavy work; use lazy generation where possible.  
- Ensure caret and selection remain valid after layout changes and scroll sync.

Stage 1 Verification Checklist (must pass before Stage 1 build)
- log_data.txt first line = Build: ddMMMyy  
- Line numbers align with chosen policy (physical or visual)  
- Scrolling via gutter moves text; text-area vertical scroll disabled  
- Tapping line numbers navigates correctly and moves caret; keyboard suppressed in read mode

Stage 1 Build Notice
- After Stage 1 verification is complete, perform a full checkup and only then run a manual build if you confirm. Do not build automatically.

---

# Stage 2 — Interaction features & UI extras

Purpose: implement user-facing interactions, diff mode parity, and settings/UX polish after Stage 1 is confirmed.

Tasks (Stage 2)
5. Add line-number area in Diff Mode (both panes)  
6. Enable copy in Read Mode without bringing up keyboard  
7. Bottom info bar: show current (live) cursor line/col  
8. Settings → About with build number  
9. Make navigation/menu view scrollable  
10. Show/hide line number area (toggle, persisted)

Per-task summary (Stage 2)
- Task 5: Add gutter columns to both diff panes; reuse generation and tap logic; sync per-pane scrolling.  
- Task 6: Configure read-mode editor (setTextIsSelectable(true), setShowSoftInputOnFocus(false), keep longClickable) and optional explicit Copy action.  
- Task 7: Update bottom info bar on selection/text changes; compute line/col using Layout; debounce if needed.  
- Task 8: Add About entry showing app name, author ("hjltu"), versionName/versionCode and build id/date.  
- Task 9: Wrap nav/menu content in RecyclerView or NestedScrollView; ensure controls remain accessible.  
- Task 10: Add toolbar toggle + Settings preference (pref_show_line_numbers), EditorFragment.setLineNumbersVisible(boolean) to show/hide gutter, adjust layout/padding, attach/detach scroll listeners, handle edge cases for large files and animations.

Stage 2 Integration & Edge Cases
- Apply the same layout and lifecycle rules as Stage 1.  
- Ensure diff-mode retains parity with single-editor behavior.  
- When the gutter is hidden, decide and document whether editor vertical scrolling is enabled; implement toggle preserving authoritative-scroller policy coherently.

Stage 2 Verification Checklist (must pass before Stage 2 build)
- Diff mode shows line numbers for both panes and syncs correctly  
- Read Mode copy works without keyboard appearing  
- Bottom info bar updates live for cursor line/col  
- Settings → About displays build number  
- Drawer/menu scrolls when items overflow  
- Show/hide gutter toggle persists and behaves correctly across restarts and in diff mode

Stage 2 Build Notice
- After Stage 2 verification is complete, perform a full checkup and only then run a manual build if you confirm. Do not build automatically.

---

## Global Integration & Edge Cases (applies to both stages)
- Always wait for layout completion before calling EditText.getLayout() — use view.post or OnGlobalLayoutListener.  
- For large files and diff mode, prefer RecyclerView for gutter to support virtualization.  
- Avoid heavy computation in scroll callbacks; compute positions using Layout APIs and minimal arithmetic.  
- Ensure selection and caret updates do not inadvertently request soft input in read flows (showSoftInputOnFocus=false).  
- Keep methods idempotent and safe during initialization; prefer View#setVisibility over remove/inflate for toggles.  
- Announce UI visibility changes for accessibility.

---


