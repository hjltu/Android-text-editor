# Text Editor Fix Plan

This document outlines all bugs and issues found in the app, ordered by dependency and priority.

---

## Phase 1: Critical Bug Fixes

### Step 1 - Fix DiffEditorView Crash (CRITICAL)
**Problem**: `DiffEditorView` constructor calls `init()` which does `findViewById()` on layout IDs, but the XML layout `view_split_editor.xml` is never inflated into the `LinearLayout`. All fields (`etTop`, `etBottom`, `tvTopLabel`, etc.) are null → NullPointerException when `setDocuments()` is called.

**Location**: `app/src/main/java/com/example/texteditor/ui/editor/DiffEditorView.java`

**Fix**: Inflate `R.layout.view_split_editor` into `this` before calling `findViewById()` in `init()`.

---

### Step 2 - Fix EditorFragment: Read Mode Behavior
**Problem**: Read mode blocks all interaction (scroll, select, copy) because `EditText` is disabled.

**Required behavior**:
- Read mode: Scroll, select text, copy allowed. NO keyboard on tap.
- Write mode: Full editing. Keyboard appears when tapping text.

**Location**: `app/src/main/java/com/example/texteditor/ui/editor/EditorFragment.java`

**Fix**:
- Read mode: Keep `EditText` enabled but disable input type: `setInputType(EditorInfo.TYPE_NULL)` or `setFocusable(false)` + `setFocusableInTouchMode(false)`.
- Write mode: Set normal input type and make focusable in touch mode.
- Remove auto `showSoftInput()` call — keyboard should show naturally when EditText is focused in touch mode.

---

### Step 3 - Fix Mode Toggle Not Updating Immediately
**Problem**: When clicking the mode toggle button, the `Document.mode` changes but `EditorFragment` doesn't update until the tab is re-selected (because `updateEditorMode()` is only called in `observeViewModel()` when `currentTabIndex` changes).

**Location**: `MainActivity.java`, `MainViewModel.java`, `EditorFragment.java`

**Fix**:
- Add `refreshDocuments()` method to `MainViewModel` that simply calls `openDocuments.setValue(docs)` to trigger observer.
- In `MainActivity.toggleMode()`, after toggling mode, call `mainViewModel.refreshDocuments()`.

---

## Phase 2: UI Improvements

### Step 4 - Remove "Split View" from Menu
**Problem**: Split view feature exists in XML but isn't implemented in code. Confusing to users.

**Location**: `app/src/main/res/layout/nav_menu_content.xml`

**Fix**: Delete the `<TextView android:id="@+id/menu_split"...` line.

---

### Step 5 - Fix "X" Close Button Style
**Problem**: Close button using `Button` widget with "X" text looks ugly, has background, inconsistent size.

**Location**: `MainActivity.java` - `updateOpenFilesList()` method

**Fix**: Replace with a `TextView` styled as a clean "X" icon:
- No background
- Centered in its own column
- Same height as filename text
- Text: "×" or "X"

---

### Step 6 - Title Shows Filename with Ellipsis, Full Path on Tap
**Problem**: Long filenames break the layout or get truncated awkwardly. Title should show "..." for long names.

**Location**: `app/src/main/res/layout/activity_main.xml`, `MainActivity.java`

**Fix**:
- Add to `tv_title`:
  ```xml
  android:ellipsize="end"
  android:maxLines="1"
  android:singleLine="true"
  ```
- Add click listener to toggle between:
  - Short: filename only (e.g., "document.txt")
  - Full: full path when user taps

---

### Step 7 - Move Font +/- to Collapsible Settings Section
**Problem**: Font controls clutter the main menu.

**Location**: `nav_menu_content.xml`, `MainActivity.java`

**Fix**:
- Group font controls under a "Settings" header that expands/collapses.
- Or hide by default and show only when settings menu item is tapped.

---

### Step 8 - Fix Font Size Only Having 2 Values
**Problem**: Font size appears to only have 2 values because `ZoomEditText.init()` hard-codes `setTextSize(14f)` which overrides the initial value. The `EditorFragment` observes `defaultFontSize` and calls `etEditor.setTextSize(size)`, but then `ZoomEditText.onTouchEvent` (pinch zoom) modifies its own internal text size.

**Location**: `app/src/main/java/com/example/texteditor/ui/editor/ZoomEditText.java`, `EditorFragment.java`

**Fix**:
- Remove the hardcoded `setTextSize(14f)` in `ZoomEditText.init()`.
- Let the initial size come from XML or ViewModel.
- Font menu buttons already step by 1 — this is correct.

---

### Step 9 - Fix Save Logic (Filename After Save)
**Problem**: After Save As, `setFilename(uri.getPath())` sets the full path like `/tree/primary:Documents/...` which looks weird. Need to extract just the filename portion.

**Location**: `MainActivity.java` - `handleSaveAs()`

**Fix**:
- Parse the URI to get just the filename portion instead of full path.
- Use `ContentResolver.query()` with `DocumentsContract.Document.COLUMN_DISPLAY_NAME` to get proper display name.

---

## Phase 3: New Features

### Step 10 - Diff View: Open Files Dialog for Two Files
**Problem**: Current diff view requires two files to already be open, then shows the first two. This is limiting.

**Location**: `MainActivity.java` - `showDiffView()`

**Fix**:
- Create a dialog to select two files from open documents (or prompt to open if fewer than 2 open).
- OR: Use `ACTION_OPEN_DOCUMENT` twice (first file, then second file) to select files specifically for diff.

---

## Summary Table

| # | Issue | Severity | Complexity |
|---|-------|----------|------------|
| 1 | DiffEditorView crash | CRITICAL | Low |
| 2 | Read/Write mode keyboard | HIGH | Medium |
| 3 | Mode toggle not updating | HIGH | Low |
| 4 | Remove Split View from menu | LOW | Low |
| 5 | Close button style | MEDIUM | Low |
| 6 | Title ellipsis | LOW | Low |
| 7 | Font controls in settings | LOW | Low |
| 8 | Font size logic | MEDIUM | Medium |
| 9 | Save filename path | MEDIUM | Medium |
| 10 | Diff view file selection | MEDIUM | Medium |

---

**Recommended Order**: 1 → 2 → 3 → 8 → 4 → 5 → 6 → 7 → 9 → 10
