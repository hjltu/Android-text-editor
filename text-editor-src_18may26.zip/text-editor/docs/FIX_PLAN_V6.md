# Fix Plan v6: Code Review & Bug Fixes

**Date:** 2026-05-18
**Goal:** Resolve regressions in tab switching, status bar behavior, and gutter navigation, while improving overall architectural consistency.
**Core Principle:** Each open tab must function independently. State—including read/edit mode, cursor position, and scroll offset—must be isolated per file, allowing different tabs to be in different modes (e.g., Tab A is Read-Only while Tab B is Editable).

## 1. Code Review & Pattern Analysis
- **Objective:** Identify "bad patterns" (e.g., leaking contexts, inefficient view updates, fragmented state management).
- **Focus Areas:** `EditorFragment`, `EditorViewModel`, and `MainViewModel`.
- **Action:** Audit how document state and read/write modes are propagated between the ViewModel and UI.

## 2. Bug Fixes

### Bug 1: Read/Edit Mode Regression on Tab Switch
- **Symptom:** Mode does not transition instantly when switching tabs.
- **Hypothesis:** Mode state is either not persisted per-document or is being overridden by a default value during fragment recreation/attachment.
- **Fix:** Ensure `Document` model or `EditorViewModel` maintains the mode per tab and apply it during `onViewCreated` or `onResume`.

### Bug 2: Status Bar Line/Col Blinking
- **Symptom:** Spontaneous changes/blinking of the coordinates.
- **Hypothesis:** Race condition between multiple listeners updating the status bar or excessive re-renders triggered by minor cursor movements.
- **Fix:** Debounce updates or unify the source of truth for cursor position updates.

### Bug 3: Line Gutter Navigation (Missing Feature)
- **Symptom:** Clicking the line gutter does not move the cursor to that line.
- **Fix:** Implement a click listener on the gutter view that calculates the line index based on the click position and calls `setTextViewSelection` or equivalent in `ZoomEditText`.

### Bug 4: Dirty Mark Visibility Regression
- **Symptom:** Unsaved changes indicator is missing.
- **Hypothesis:** The "isDirty" flag is not being updated correctly in the `Document` model or the UI observer in the tab/toolbar is not reacting to it.
- **Fix:** Verify `Document.setDirty()` is called on text change and that the UI correctly binds to this state.

## 3. General Consistency Cleanup
- **Objective:** Make the implementation "integral."
- **Action:** 
    - Standardize how "Read Only" vs "Edit" modes are handled across the app.
    - Ensure consistent error handling and logging using `AppLogger`.
    - Remove any dead code or redundant state variables discovered during review.
