# Implementation Plan: Text Editor Refinements & Bug Fixes

## 1. Core Functions & Bug Fixes
- [ ] **New File Mode**: Update `MainActivity.handleNewFile()` to set `Document.Mode.READ` by default.
- [ ] **Keyboard Trigger**: Add `requestFocus()` and `InputMethodManager` calls in `EditorFragment` when switching to `WRITE` mode.
- [ ] **Content Loading (Bug 2)**: Fix the data link between `MainViewModel` and `EditorViewModel` to ensure file content is displayed upon opening.
- [ ] **App Log System**: 
    - Implement a global logger that captures app events and errors.
    - Create a special `log_data.txt` Document that is always the last item in the file list.
    - Ensure the log document is updated in real-time and can be saved as a standard text file.
- [ ] **Crash Investigation (Bug 1)**: Use the new App Log system in `SAFManager` and `MainActivity` to identify causes of crashes during file operations.
- [ ] **Top Menu Title (Bug 3)**: Update `MainActivity` to observe `currentTabIndex` and set `tv_title` to the current document's filename.

## 2. Diff View & Split View
- [ ] **Remove Split View**: Delete `SplitEditorView.java` and remove all references in `MainActivity.java`.
- [ ] **Diff View Layout**: Add a "Swap Top/Bottom" button to `R.layout.view_split_editor`.
- [ ] **Diff View Logic**: 
    - Implement the swap functionality in `DiffEditorView.java`.
    - Implement `updateModes()` in `DiffEditorView.java` to allow `WRITE` mode for the top editor.

## 3. File Management (Open Files)
- [ ] **Unique Untitled Names**: Implement a counter in `MainViewModel` for `untitled_XX.txt` naming convention.
- [ ] **Close Files**: 
    - Add "X" close buttons to the navigation drawer file list.
    - Implement the closing logic in `MainViewModel`, blocking closure of "dirty" files.
- [ ] **Tab Navigation**: Verify/Fix tapping filename in drawer to trigger `switchTab(index)`.
- [ ] **Tab Integrity**: Ensure `EditorPagerAdapter` maintains a strict 1:1 mapping of Document to Fragment.

## 4. Settings & UI
- [ ] **Line Numbers**: Implement scroll synchronization between `ZoomEditText` and `rv_line_numbers` in `EditorFragment`.
- [ ] **Typography Settings**: Add UI/Logic to adjust default font size and style for `ZoomEditText`.
- [ ] **Bottom Info Bar**: Add a status bar to `activity_main.xml` for file info (line/col) and total tab count.

## 5. Final Verification
- [ ] Verify tab rotation and swipe cycling.
- [ ] Verify "Save before switch" state safety.
- [ ] End-to-end regression test of all edited flows.
