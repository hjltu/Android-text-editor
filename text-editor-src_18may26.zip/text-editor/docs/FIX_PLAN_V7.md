# Fix Plan v7: Architectural Hardening & Performance

**Context:**
Following the completion of Fix Plan v6, the app is functionally stable and the requested bugs are resolved. However, a code review revealed significant architectural risks—specifically main-thread I/O and redundant state management—that will lead to instability (ANRs) as file sizes grow and complexity increases. This plan focuses on moving the app from "working" to "robust."

## 1. Asynchronous I/O Implementation
**Problem:** `SAFManager` read/write operations are performed on the UI thread in `MainActivity`, which will cause ANRs for larger files.

**Approach:**
- Introduce a background execution pattern using `viewModelScope` (Kotlin Coroutines) or a dedicated `Executor` if remaining in Java. 
- Since the project is primarily Java, I will implement a `BackgroundExecutor` utility or use `CompletableFuture` to handle I/O.
- **Critical Files:**
    - `text-editor/app/src/main/java/com/example/texteditor/ui/main/MainActivity.java`: Modify `handleOpenDocument`, `handleSave`, `handleSaveAs`, and `setupDiffViewFromUris` to execute I/O asynchronously.
    - `text-editor/app/src/main/java/com/example/texteditor/data/saf/SAFManager.java`: (Review if internal methods need adjustment for thread safety).

**Verification:**
- Open a large text file (>1MB) and verify the UI remains responsive during the load.
- Save a large file and ensure the "File saved" toast appears without freezing the screen.

## 2. ViewModel State Unification
**Problem:** State is duplicated between `EditorViewModel` and `MainViewModel`, leading to fragmented updates and potential sync issues.

**Approach:**
- Transition `EditorViewModel` from a "state holder" to a "state bridge."
- Instead of maintaining its own `MutableLiveData<Document>`, `EditorViewModel` will act as a proxy to the document stored in `MainViewModel`'s list.
- Remove redundant `currentDocument`, `isDirty`, and `currentMode` LiveDatas from `EditorViewModel` if they can be derived directly from the `Document` object in `MainViewModel`.
- **Critical Files:**
    - `text-editor/app/src/main/java/com/example/texteditor/ui/editor/EditorViewModel.java`: Remove redundant state.
    - `text-editor/app/src/main/java/com/example/texteditor/ui/editor/EditorFragment.java`: Update observers to rely on a single source of truth from `MainViewModel`.

**Verification:**
- Switch tabs and verify that mode and content updates are consistent.
- Toggle edit mode and verify the change is reflected across both ViewModel contexts immediately.

## 3. Lifecycle & Resource Optimization
**Problem:** Potential for minor leaks and inefficient updates.

**Approach:**
- Audit `EditorFragment` for any remaining `Handler` or `Listener` leaks.
- Ensure `ShoraredPreferences` listeners are always unregistered.
- **Critical Files:**
    - `text-editor/app/src/main/java/com/example/texteditor/ui/editor/EditorFragment.java`.

**Verification:**
- Rapidly open and close documents to check for memory growth or leaked callback warnings in Logcat.

## 4. Find Text Functionality
**Problem:** The editor lacks a way to search for specific text within a document.

**Approach:**
- **UI Layer:** Implement a search bar (top overlay or bottom sheet) with a text input, "Next", "Previous" buttons, and a "Case Sensitive" toggle.
- **Logic Layer:**
    - implement search using `String.indexOf` with a loop to track all occurrences.
    - Use circular indexing to allow "Next" to wrap around to the start of the file.
- **Visual Feedback:**
    - Use `etEditor.setSelection(start, end)` to highlight the current match.
    - Use `etEditor.scrollTo(...)` to move the viewport to the matched line.
    - (Optional) Apply `ForegroundColorSpan` or `BackgroundColorSpan` to all matches for a global overview.
- **Critical Files:**
    - `text-editor/app/src/main/java/com/example/texteditor/ui/editor/EditorViewModel.java`: Add search state (current match index, total matches) and search logic.
    - `text-editor/app/src/main/java/com/example/texteditor/ui/editor/EditorFragment.java`: Implement the search UI and the logic to move the cursor/highlight text.
    - `text-editor/app/src/main/res/layout/fragment_editor.xml`: Add search UI components.

**Verification:**
- Search for a known string and verify the cursor jumps to the first occurrence.
- Use "Next" and "Previous" buttons to cycle through all matches.
- Toggle "Case Sensitive" and verify search results change accordingly.
