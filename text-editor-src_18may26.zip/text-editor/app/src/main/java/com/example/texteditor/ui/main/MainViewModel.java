package com.example.texteditor.ui.main;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;
import com.example.texteditor.model.Document;
import java.util.ArrayList;
import java.util.List;

public class MainViewModel extends ViewModel {
    private final MutableLiveData<List<Document>> openDocuments = new MutableLiveData<>(new ArrayList<>());
    private final MutableLiveData<Integer> currentTabIndex = new MutableLiveData<>(0);
    private Document logDocument;
    private int untitledCounter = 1;
    private final MutableLiveData<Integer> defaultFontSize = new MutableLiveData<>(14);

    public MainViewModel() {
        initLogDocument();
    }

    private void initLogDocument() {
        logDocument = new Document(null, "log_data.txt", "");
        logDocument.setMode(Document.Mode.READ);
        updateLogContent();

        List<Document> docs = openDocuments.getValue();
        if (docs == null) docs = new ArrayList<>();
        docs.add(logDocument);
        openDocuments.setValue(docs);
    }

    public void updateLogContent() {
        logDocument.setContent(com.example.texteditor.util.LogBuffer.getContent());
        List<Document> currentDocs = openDocuments.getValue();
        if (currentDocs != null) {
            openDocuments.setValue(currentDocs);
        }
    }

    public String generateUntitledName() {
        return String.format("untitled_%02d.txt", untitledCounter++);
    }

    public LiveData<Integer> getDefaultFontSize() {
        return defaultFontSize;
    }

    public void adjustFontSize(int delta) {
        int current = defaultFontSize.getValue() != null ? defaultFontSize.getValue() : 14;
        int newSize = current + delta;
        if (newSize >= 8 && newSize <= 72) {
            defaultFontSize.setValue(newSize);
        }
    }

    public LiveData<List<Document>> getOpenDocuments() {
        return openDocuments;
    }

    public LiveData<Integer> getCurrentTabIndex() {
        return currentTabIndex;
    }

    public void addDocument(Document doc) {
        List<Document> docs = openDocuments.getValue();
        if (docs == null) docs = new ArrayList<>();

        // Check if document is already open to avoid duplicates
        for (int i = 0; i < docs.size(); i++) {
            if (docs.get(i).getUri() != null && doc.getUri() != null &&
                docs.get(i).getUri().equals(doc.getUri())) {
                currentTabIndex.setValue(i);
                return;
            }
        }

        // Remove log if it exists to re-add it at the end
        docs.remove(logDocument);
        docs.add(doc);
        docs.add(logDocument);

        openDocuments.setValue(docs);
        currentTabIndex.setValue(docs.size() - 2); // Index before logDocument
    }

    public void switchTab(int index) {
        int size = openDocuments.getValue() != null ? openDocuments.getValue().size() : 0;
        if (size == 0) return;

        // Implement modulo indexing for continuous looping
        int wrappedIndex = (index % size + size) % size;
        currentTabIndex.setValue(wrappedIndex);
    }

    public Document getCurrentDocument() {
        List<Document> docs = openDocuments.getValue();
        Integer index = currentTabIndex.getValue();
        if (docs != null && index != null && index >= 0 && index < docs.size()) {
            return docs.get(index);
        }
        return null;
    }

    public void closeDocument(int index) {
        List<Document> docs = openDocuments.getValue();
        if (docs != null && index >= 0 && index < docs.size()) {
            docs.remove(index);
            openDocuments.setValue(docs);

            // Adjust current index if needed
            Integer current = currentTabIndex.getValue();
            if (current != null && current >= docs.size()) {
                currentTabIndex.setValue(Math.max(0, docs.size() - 1));
            }
        }
    }

    public void refreshDocuments() {
        List<Document> docs = openDocuments.getValue();
        if (docs != null) {
            openDocuments.setValue(docs);
        }
    }

    /**
     * Attempts to close a document. Returns true if document was closed,
     * false if close was blocked due to dirty file.
     */
    public boolean tryCloseDocument(int index) {
        List<Document> docs = openDocuments.getValue();
        if (docs != null && index >= 0 && index < docs.size()) {
            Document doc = docs.get(index);
            if (doc.isDirty()) {
                return false; // Block closing dirty files
            }
            docs.remove(index);
            openDocuments.setValue(docs);

            // Adjust current index if needed
            Integer current = currentTabIndex.getValue();
            if (current != null && current >= docs.size()) {
                currentTabIndex.setValue(Math.max(0, docs.size() - 1));
            }
            return true;
        }
        return false;
    }
}
