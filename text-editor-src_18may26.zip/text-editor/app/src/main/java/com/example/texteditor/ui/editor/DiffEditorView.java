package com.example.texteditor.ui.editor;

import android.content.Context;
import android.text.SpannableStringBuilder;
import android.util.AttributeSet;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.texteditor.R;
import com.example.texteditor.model.Document;
import com.example.texteditor.util.DiffResult;
import com.example.texteditor.util.DiffUtil;

public class DiffEditorView extends LinearLayout {

    private Document topDoc;
    private Document bottomDoc;
    private EditText etTop;
    private EditText etBottom;
    private TextView tvTopLabel;
    private TextView tvBottomLabel;
    private RecyclerView rvLineNumbersTop;
    private RecyclerView rvLineNumbersBottom;
    private LineNumberAdapter lineNumberAdapterTop;
    private LineNumberAdapter lineNumberAdapterBottom;
    private android.content.SharedPreferences.OnSharedPreferenceChangeListener lineNumbersPreferenceListener;

    public DiffEditorView(@NonNull Context context) {
        super(context);
        init();
    }

    public DiffEditorView(@NonNull Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    private void init() {
        // Inflate layout into this LinearLayout - attachToParent must be true
        inflate(getContext(), R.layout.view_split_editor, this);

        etTop = findViewById(R.id.et_top);
        etBottom = findViewById(R.id.et_bottom);
        tvTopLabel = findViewById(R.id.tv_top_label);
        tvBottomLabel = findViewById(R.id.tv_bottom_label);
        rvLineNumbersTop = findViewById(R.id.rv_line_numbers_top);
        rvLineNumbersBottom = findViewById(R.id.rv_line_numbers_bottom);
        android.widget.Button btnSwap = findViewById(R.id.btn_swap_files);

        // Load preference for showing line numbers
        android.content.SharedPreferences prefs = getContext().getSharedPreferences("settings", android.content.Context.MODE_PRIVATE);
        boolean showLineNumbers = prefs.getBoolean("show_line_numbers", true);
        setLineNumbersVisible(showLineNumbers);

        lineNumbersPreferenceListener = (prefsShared, key) -> {
            if ("show_line_numbers".equals(key)) {
                boolean visible = prefsShared.getBoolean(key, true);
                setLineNumbersVisible(visible);
            }
        };
        prefs.registerOnSharedPreferenceChangeListener(lineNumbersPreferenceListener);

        // Setup line number adapters with references to their corresponding EditTexts
        lineNumberAdapterTop = new LineNumberAdapter(etTop);
        lineNumberAdapterBottom = new LineNumberAdapter(etBottom);
        rvLineNumbersTop.setAdapter(lineNumberAdapterTop);
        rvLineNumbersBottom.setAdapter(lineNumberAdapterBottom);
        rvLineNumbersTop.setLayoutManager(new LinearLayoutManager(getContext()));
        rvLineNumbersBottom.setLayoutManager(new LinearLayoutManager(getContext()));

        // Update line numbers after layout is complete for both panes
        etTop.getViewTreeObserver().addOnGlobalLayoutListener(() -> updateLineNumbers());
        etBottom.getViewTreeObserver().addOnGlobalLayoutListener(() -> updateLineNumbers());

        // Make gutter the primary scroller for top pane; disable text-area vertical scroll
        rvLineNumbersTop.setOnScrollChangeListener((v, scrollX, scrollY, oldScrollX, oldScrollY) -> {
            // Scroll top editor to match gutter position
            etTop.post(() -> {
                if (etTop.getLayout() != null && rvLineNumbersTop.getLayoutManager() != null) {
                    androidx.recyclerview.widget.LinearLayoutManager lm = (androidx.recyclerview.widget.LinearLayoutManager) rvLineNumbersTop.getLayoutManager();
                    int firstVisibleLine = lm.findFirstVisibleItemPosition();
                    if (firstVisibleLine >= 0 && firstVisibleLine < etTop.getLayout().getLineCount()) {
                        int top = etTop.getLayout().getLineTop(firstVisibleLine);
                        etTop.scrollTo(etTop.getScrollX(), top);
                    }
                }
            });
        });

        // Make gutter the primary scroller for bottom pane; disable text-area vertical scroll
        rvLineNumbersBottom.setOnScrollChangeListener((v, scrollX, scrollY, oldScrollX, oldScrollY) -> {
            // Scroll bottom editor to match gutter position
            etBottom.post(() -> {
                if (etBottom.getLayout() != null && rvLineNumbersBottom.getLayoutManager() != null) {
                    androidx.recyclerview.widget.LinearLayoutManager lm = (androidx.recyclerview.widget.LinearLayoutManager) rvLineNumbersBottom.getLayoutManager();
                    int firstVisibleLine = lm.findFirstVisibleItemPosition();
                    if (firstVisibleLine >= 0 && firstVisibleLine < etBottom.getLayout().getLineCount()) {
                        int top = etBottom.getLayout().getLineTop(firstVisibleLine);
                        etBottom.scrollTo(etBottom.getScrollX(), top);
                    }
                }
            });
        });

        // Disable vertical scroll in text areas (keep horizontal scroll if needed)
        etTop.setVerticalScrollBarEnabled(false);
        etTop.setOverScrollMode(android.view.View.OVER_SCROLL_NEVER);
        etBottom.setVerticalScrollBarEnabled(false);
        etBottom.setOverScrollMode(android.view.View.OVER_SCROLL_NEVER);

        if (btnSwap != null) {
            btnSwap.setOnClickListener(v -> {
                Document temp = topDoc;
                topDoc = bottomDoc;
                bottomDoc = temp;
                setDocuments(topDoc, bottomDoc);
            });
        }
    }

    public void setLineNumbersVisible(boolean visible) {
        if (rvLineNumbersTop != null) rvLineNumbersTop.setVisibility(visible ? View.VISIBLE : View.GONE);
        if (rvLineNumbersBottom != null) rvLineNumbersBottom.setVisibility(visible ? View.VISIBLE : View.GONE);

        // Adjust vertical scroll based on gutter visibility
        etTop.setVerticalScrollBarEnabled(visible ? false : true);
        etTop.setOverScrollMode(visible ? View.OVER_SCROLL_NEVER : View.OVER_SCROLL_ALWAYS);
        etBottom.setVerticalScrollBarEnabled(visible ? false : true);
        etBottom.setOverScrollMode(visible ? View.OVER_SCROLL_NEVER : View.OVER_SCROLL_ALWAYS);
    }

    public void dispose() {
        if (lineNumbersPreferenceListener != null) {
            android.content.SharedPreferences prefs = getContext().getSharedPreferences("settings", android.content.Context.MODE_PRIVATE);
            prefs.unregisterOnSharedPreferenceChangeListener(lineNumbersPreferenceListener);
        }
    }

    public void setDocuments(Document oldDoc, Document newDoc) {
        this.topDoc = oldDoc;
        this.bottomDoc = newDoc;

        tvTopLabel.setText("Top: " + oldDoc.getFilename());
        tvBottomLabel.setText("Bottom: " + newDoc.getFilename());

        // Perform Diff
        DiffResult result = DiffUtil.diff(oldDoc.getContent(), newDoc.getContent());

        // Apply Highlighting
        SpannableStringBuilder topText = DiffUtil.applyHighlighting(result.oldLines);
        SpannableStringBuilder bottomText = DiffUtil.applyHighlighting(result.newLines);

        // Set Text with SPANNABLE buffer type to preserve colors
        etTop.setText(topText, EditText.BufferType.SPANNABLE);
        etBottom.setText(bottomText, EditText.BufferType.SPANNABLE);

        // Update line numbers for both panes
        updateLineNumbers();

        updateModes();
    }

    private void updateLineNumbers() {
        // Update line numbers for top pane
        if (etTop.getLayout() != null) {
            int topLines = etTop.getLayout().getLineCount();
            lineNumberAdapterTop.setLineCount(topLines);
        }

        // Update line numbers for bottom pane
        if (etBottom.getLayout() != null) {
            int bottomLines = etBottom.getLayout().getLineCount();
            lineNumberAdapterBottom.setLineCount(bottomLines);
        }
    }

    private void updateModes() {
        // Top file: follow its own mode
        if (topDoc.getMode() == Document.Mode.WRITE) {
            etTop.setEnabled(true);
            etTop.setFocusable(true);
            etTop.setFocusableInTouchMode(true);
            etTop.setInputType(android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE);
            // Ensure we have a valid key listener (restore default if needed)
            if (etTop.getKeyListener() == null) {
                EditText temp = new EditText(getContext());
                etTop.setKeyListener(temp.getKeyListener());
            }
            etTop.setCursorVisible(true);
            etTop.setShowSoftInputOnFocus(true);
            etTop.setTextIsSelectable(true);
            // Request focus and show keyboard after view is laid out
            etTop.post(() -> {
                etTop.requestFocus();
            });
        } else {
            applyReadMode(etTop);
        }

        // Bottom file: always read-only in diff view
        applyReadMode(etBottom);
    }

    private void applyReadMode(EditText et) {
        et.setEnabled(true);
        et.setFocusable(false);
        et.setFocusableInTouchMode(false);
        et.setInputType(android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        et.setKeyListener(null);
        et.setTextIsSelectable(true);
        et.setShowSoftInputOnFocus(false);
        et.setLongClickable(true);
        et.setCursorVisible(false);
    }

    private static class LineNumberAdapter extends androidx.recyclerview.widget.RecyclerView.Adapter<LineNumberAdapter.ViewHolder> {
        private int lineCount = 0;
        private final EditText editor;

        public LineNumberAdapter(EditText editor) {
            this.editor = editor;
        }

        public void setLineCount(int count) {
            this.lineCount = count;
            notifyDataSetChanged();
        }

        @Override
        public int getItemCount() { return lineCount; }

        @Override
        public ViewHolder onCreateViewHolder(android.view.ViewGroup parent, int viewType) {
            android.widget.TextView tv = new android.widget.TextView(parent.getContext());
            tv.setGravity(android.view.Gravity.TOP);
            tv.setPadding(0, 8, 0, 8);
            tv.setTextColor(android.graphics.Color.GRAY);
            tv.setClickable(true);
            tv.setFocusable(true);
            return new ViewHolder(tv);
        }

        @Override
        public void onBindViewHolder(ViewHolder holder, int position) {
            if (editor.getLayout() != null) {
                int offset = editor.getLayout().getLineStart(position);
                String textBefore = editor.getText().subSequence(0, offset).toString();
                int physicalLine = 1;
                for (int i = 0; i < textBefore.length(); i++) {
                    if (textBefore.charAt(i) == '\n') physicalLine++;
                }
                ((android.widget.TextView) holder.view).setText(String.valueOf(physicalLine));
            } else {
                ((android.widget.TextView) holder.view).setText(String.valueOf(position + 1));
            }

            holder.view.setOnClickListener(v -> {
                if (editor.getLayout() != null) {
                    int tappedVisualLine = position;
                    int offset = editor.getLayout().getLineStart(tappedVisualLine);
                    editor.requestFocus();
                    editor.setSelection(offset);
                    // Ensure the line is visible
                    editor.scrollTo(editor.getScrollX(), editor.getLayout().getLineTop(tappedVisualLine));
                }
            });
        }

        static class ViewHolder extends androidx.recyclerview.widget.RecyclerView.ViewHolder {
            View view;
            ViewHolder(View view) { super(view); this.view = view; }
        }
    }
}
