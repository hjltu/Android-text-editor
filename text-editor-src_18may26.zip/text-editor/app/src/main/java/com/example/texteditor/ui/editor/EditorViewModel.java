package com.example.texteditor.ui.editor;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;
import com.example.texteditor.model.Document;

public class EditorViewModel extends ViewModel {
    private final MutableLiveData<Document> currentDocument = new MutableLiveData<>();
    private final MutableLiveData<Boolean> isDirty = new MutableLiveData<>(false);
    private final MutableLiveData<Document.Mode> currentMode = new MutableLiveData<>(Document.Mode.READ);

    public LiveData<Document> getCurrentDocument() {
        return currentDocument;
    }

    public LiveData<Boolean> isDirty() {
        return isDirty;
    }

    public LiveData<Document.Mode> getCurrentMode() {
        return currentMode;
    }

    public void setDocument(Document doc) {
        currentDocument.setValue(doc);
        isDirty.setValue(doc.isDirty());
        currentMode.setValue(doc.getMode());
    }

    public void updateContent(String newContent) {
        Document doc = currentDocument.getValue();
        if (doc != null && !doc.getContent().equals(newContent)) {
            doc.setContent(newContent);
            doc.setDirty(true);
            isDirty.setValue(true);
        }
    }

    public void setDirty(boolean dirty) {
        Document doc = currentDocument.getValue();
        if (doc != null) {
            doc.setDirty(dirty);
            isDirty.setValue(dirty);
        }
    }

    public void toggleMode() {
        Document doc = currentDocument.getValue();
        if (doc == null) return;

        Document.Mode newMode = (currentMode.getValue() == Document.Mode.READ)
            ? Document.Mode.WRITE
            : Document.Mode.READ;

        doc.setMode(newMode);
        currentMode.setValue(newMode);
    }
}
