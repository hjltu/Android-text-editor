package com.example.texteditor.ui.editor;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import com.example.texteditor.R;
import java.util.List;
import com.example.texteditor.model.Document;

public class EditorFragment extends Fragment {

    private static final String ARG_DOC_INDEX = "doc_index";
    private int documentIndex = -1;
    private EditorViewModel viewModel;
    private EditText etEditor;
    private androidx.recyclerview.widget.RecyclerView rvLineNumbers;
    private LineNumberAdapter lineNumberAdapter;
    private android.content.SharedPreferences.OnSharedPreferenceChangeListener lineNumbersPreferenceListener;
    private android.os.Handler cursorUpdateHandler = new android.os.Handler();
    private Runnable cursorUpdateRunnable = new Runnable() {
        @Override
        public void run() {
            if (etEditor != null && isAdded()) {
                updateCursorPosition();
            }
            cursorUpdateHandler.postDelayed(this, 500);
        }
    };

    public static EditorFragment newInstance(int index) {
        EditorFragment fragment = new EditorFragment();
        Bundle args = new Bundle();
        args.putInt(ARG_DOC_INDEX, index);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        if (getArguments() != null) {
            documentIndex = getArguments().getInt(ARG_DOC_INDEX);
        }
        View view = inflater.inflate(R.layout.fragment_editor, container, false);

        etEditor = view.findViewById(R.id.et_editor);
        viewModel = new ViewModelProvider(this).get(EditorViewModel.class);

        setupTextWatcher();
        observeViewModel();
        setupLineNumbers(view);

        etEditor.setOnTouchListener(new View.OnTouchListener() {
            private float lastX, lastY;

            @Override
            public boolean onTouch(View v, android.view.MotionEvent event) {
                int action = event.getAction();
                switch (action) {
                    case android.view.MotionEvent.ACTION_DOWN:
                        lastX = event.getX();
                        lastY = event.getY();
                        // Request disallow intercept immediately on touch down to prevent
                        // ViewPager2 from stealing the initial touch.
                        if (v.getParent() != null) {
                            v.getParent().requestDisallowInterceptTouchEvent(true);
                        }
                        break;
                    case android.view.MotionEvent.ACTION_MOVE:
                        float dx = Math.abs(event.getX() - lastX);
                        float dy = Math.abs(event.getY() - lastY);
                        if (dy > dx) {
                            // Vertical movement dominates, ensure ViewPager2 doesn't intercept
                            if (v.getParent() != null) {
                                v.getParent().requestDisallowInterceptTouchEvent(true);
                            }
                        } else if (dx > 10) {
                            // Horizontal movement is significant, allow ViewPager2 to potentially intercept
                            if (v.getParent() != null) {
                                v.getParent().requestDisallowInterceptTouchEvent(false);
                            }
                        }
                        lastX = event.getX();
                        lastY = event.getY();
                        break;
                    case android.view.MotionEvent.ACTION_UP:
                    case android.view.MotionEvent.ACTION_CANCEL:
                        updateCursorPosition();
                        if (v.getParent() != null) {
                            v.getParent().requestDisallowInterceptTouchEvent(false);
                        }
                        break;
                }
                // Return false to allow EditText to handle the touch event normally
                // (e.g., for cursor movement, text selection, and long-press menus).
                return false;
            }
        });

        // Start live cursor tracking
        cursorUpdateHandler.postDelayed(cursorUpdateRunnable, 200);

        return view;
    }

    private void setupTextWatcher() {
        etEditor.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int after) {
                String content = s.toString();
                viewModel.updateContent(content);

                com.example.texteditor.ui.main.MainViewModel mainViewModel = new ViewModelProvider(requireActivity()).get(com.example.texteditor.ui.main.MainViewModel.class);
                int index = getArguments() != null ? getArguments().getInt(ARG_DOC_INDEX) : 0;
                List<Document> docs = mainViewModel.getOpenDocuments().getValue();
                if (docs != null && index < docs.size()) {
                    Document doc = docs.get(index);
                    if (!doc.getContent().equals(content)) {
                        doc.setContent(content);
                        doc.setDirty(true);
                        mainViewModel.refreshDocuments();
                    }
                }

                etEditor.post(() -> {
                    if (lineNumberAdapter != null && etEditor.getLayout() != null) {
                        int visualLines = etEditor.getLayout().getLineCount();
                        lineNumberAdapter.setLineCount(visualLines);
                    }
                });
                updateCursorPosition();
            }

            @Override
            public void afterTextChanged(Editable s) {}
        });
    }

    private void updateCursorPosition() {
        if (etEditor == null) return;

        int pos = etEditor.getSelectionStart();
        String text = etEditor.getText().toString();
        int line = 1;
        for (int i = 0; i < pos && i < text.length(); i++) {
            if (text.charAt(i) == '\n') line++;
        }
        int lastNewline = text.lastIndexOf('\n', pos - 1);
        int col = (lastNewline == -1) ? pos + 1 : pos - lastNewline;

        if (getActivity() instanceof com.example.texteditor.ui.main.MainActivity) {
            ((com.example.texteditor.ui.main.MainActivity) getActivity()).updateFileInfo(line, col);
        }
    }

    private void observeViewModel() {
        com.example.texteditor.ui.main.MainViewModel mainViewModel = new ViewModelProvider(requireActivity()).get(com.example.texteditor.ui.main.MainViewModel.class);
        int index = getArguments() != null ? getArguments().getInt(ARG_DOC_INDEX) : 0;

        mainViewModel.getOpenDocuments().observe(getViewLifecycleOwner(), docs -> {
            if (docs != null && index < docs.size()) {
                com.example.texteditor.model.Document doc = docs.get(index);
                if (etEditor.getText().toString().equals(doc.getContent())) {
                    // Only set text if it has changed to avoid cursor reset
                    // But we always need to ensure the mode is correct when the document is loaded
                    updateEditorMode(doc.getMode());
                } else {
                    etEditor.setText(doc.getContent());
                    updateEditorMode(doc.getMode());
                }
            }
        });

        mainViewModel.getCurrentTabIndex().observe(getViewLifecycleOwner(), currentIdx -> {
            if (currentIdx == index) {
                com.example.texteditor.model.Document doc = mainViewModel.getCurrentDocument();
                if (doc != null) {
                    updateEditorMode(doc.getMode());
                }
            }
        });

        mainViewModel.getDefaultFontSize().observe(getViewLifecycleOwner(), size -> {
            etEditor.setTextSize(size);
        });
    }

    private void updateEditorMode(com.example.texteditor.model.Document.Mode mode) {
        boolean isWriteMode = (mode == com.example.texteditor.model.Document.Mode.WRITE);

        if (isWriteMode) {
            // Write mode: enable text input, allow focus
            etEditor.setEnabled(true);
            etEditor.setFocusable(true);
            etEditor.setFocusableInTouchMode(true);
            etEditor.setInputType(android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE);
            // Ensure we have a valid key listener (restore default if needed)
            if (etEditor.getKeyListener() == null) {
                EditText temp = new EditText(getContext());
                etEditor.setKeyListener(temp.getKeyListener());
            }
            etEditor.setCursorVisible(true);
            etEditor.setShowSoftInputOnFocus(true);
            etEditor.setTextIsSelectable(true);
            // Request focus and show keyboard after view is laid out
            etEditor.post(() -> {
                etEditor.requestFocus();
            });
        } else {
            // Read mode: keep enabled for scroll/select/copy, but disable text input
            etEditor.setEnabled(true);
            etEditor.setFocusable(true);
            etEditor.setFocusableInTouchMode(true);
            etEditor.setInputType(android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE);
            etEditor.setKeyListener(null);
            etEditor.setCursorVisible(false);
            etEditor.setShowSoftInputOnFocus(false);
            etEditor.setTextIsSelectable(true);
            etEditor.setLongClickable(true);
        }
    }

    private void setupLineNumbers(View view) {
        rvLineNumbers = view.findViewById(R.id.rv_line_numbers);
        lineNumberAdapter = new LineNumberAdapter();
        rvLineNumbers.setAdapter(lineNumberAdapter);
        rvLineNumbers.setLayoutManager(new androidx.recyclerview.widget.LinearLayoutManager(getContext()));

        // Load preference for showing line numbers
        android.content.SharedPreferences prefs = android.preference.PreferenceManager.getDefaultSharedPreferences(getContext());
        // Wait, MainActivity used "settings" as name. Let's be consistent.
        android.content.SharedPreferences settingsPrefs = getContext().getSharedPreferences("settings", android.content.Context.MODE_PRIVATE);
        boolean showLineNumbers = settingsPrefs.getBoolean("show_line_numbers", true);
        setLineNumbersVisible(showLineNumbers);

        lineNumbersPreferenceListener = (prefsShared, key) -> {
            if ("show_line_numbers".equals(key)) {
                boolean visible = prefsShared.getBoolean(key, true);
                setLineNumbersVisible(visible);
            }
        };
        settingsPrefs.registerOnSharedPreferenceChangeListener(lineNumbersPreferenceListener);

        // Update line numbers after layout is complete
        view.getViewTreeObserver().addOnGlobalLayoutListener(() -> {
            if (etEditor.getLayout() != null) {
                int visualLines = etEditor.getLayout().getLineCount();
                lineNumberAdapter.setLineCount(visualLines);
            }
        });

        // Make gutter the primary scroller; disable text-area vertical scroll
        rvLineNumbers.setOnScrollChangeListener((v, scrollX, scrollY, oldScrollX, oldScrollY) -> {
            // Scroll editor to match gutter position
            etEditor.post(() -> {
                if (etEditor.getLayout() != null && rvLineNumbers.getLayoutManager() != null) {
                    androidx.recyclerview.widget.LinearLayoutManager lm = (androidx.recyclerview.widget.LinearLayoutManager) rvLineNumbers.getLayoutManager();
                    int firstVisibleLine = lm.findFirstVisibleItemPosition();
                    if (firstVisibleLine >= 0 && firstVisibleLine < etEditor.getLayout().getLineCount()) {
                        int top = etEditor.getLayout().getLineTop(firstVisibleLine);
                        etEditor.scrollTo(etEditor.getScrollX(), top);
                    }
                }
            });
        });

        // Disable vertical scroll in text area (keep horizontal scroll if needed)
        etEditor.setVerticalScrollBarEnabled(false);
        etEditor.setOverScrollMode(android.view.View.OVER_SCROLL_NEVER);
    }

    public void setLineNumbersVisible(boolean visible) {
        if (rvLineNumbers != null) {
            rvLineNumbers.setVisibility(visible ? View.VISIBLE : View.GONE);

            // When gutter is hidden, enable vertical scroll in text area.
            // When gutter is visible, disable vertical scroll in text area to make gutter authoritative.
            etEditor.setVerticalScrollBarEnabled(visible ? false : true);
            etEditor.setOverScrollMode(visible ? View.OVER_SCROLL_NEVER : View.OVER_SCROLL_ALWAYS);
        }
    }

    @Override
    public void onDestroyView() {
        if (lineNumbersPreferenceListener != null) {
            android.content.SharedPreferences settingsPrefs = getContext().getSharedPreferences("settings", android.content.Context.MODE_PRIVATE);
            settingsPrefs.unregisterOnSharedPreferenceChangeListener(lineNumbersPreferenceListener);
        }
        cursorUpdateHandler.removeCallbacks(cursorUpdateRunnable);
        super.onDestroyView();
    }

    private class LineNumberAdapter extends androidx.recyclerview.widget.RecyclerView.Adapter<LineNumberAdapter.ViewHolder> {
        private int lineCount = 0;

        public void setLineCount(int count) {
            this.lineCount = count;
            notifyDataSetChanged();
        }

        @Override
        public int getItemCount() { return lineCount; }

        @Override
        public ViewHolder onCreateViewHolder(android.view.ViewGroup parent, int viewType) {
            android.widget.TextView tv = new android.widget.TextView(parent.getContext());
            tv.setGravity(android.view.Gravity.TOP);
            tv.setPadding(0, 8, 0, 8);
            tv.setTextColor(android.graphics.Color.GRAY);
            tv.setClickable(true);
            tv.setFocusable(true);
            return new ViewHolder(tv);
        }

        @Override
        public void onBindViewHolder(ViewHolder holder, int position) {
            if (etEditor.getLayout() != null) {
                // Calculate physical line number for the visual line at 'position'
                int offset = etEditor.getLayout().getLineStart(position);
                String textBefore = etEditor.getText().subSequence(0, offset).toString();
                int physicalLine = 1;
                for (int i = 0; i < textBefore.length(); i++) {
                    if (textBefore.charAt(i) == '\n') physicalLine++;
                }
                ((android.widget.TextView) holder.view).setText(String.valueOf(physicalLine));
            } else {
                ((android.widget.TextView) holder.view).setText(String.valueOf(position + 1));
            }

            holder.view.setOnClickListener(v -> {
                if (etEditor.getLayout() != null) {
                    int tappedVisualLine = position;
                    int offset = etEditor.getLayout().getLineStart(tappedVisualLine);
                    etEditor.requestFocus();
                    etEditor.setSelection(offset);
                    // Ensure the line is visible
                    etEditor.scrollTo(etEditor.getScrollX(), etEditor.getLayout().getLineTop(tappedVisualLine));
                }
            });
        }

        class ViewHolder extends androidx.recyclerview.widget.RecyclerView.ViewHolder {
            View view;
            ViewHolder(View view) { super(view); this.view = view; }
        }
    }
}
