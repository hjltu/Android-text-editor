package com.example.texteditor.util;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class LogBuffer {
    private static StringBuilder buffer = new StringBuilder();
    private static boolean buildNumberAdded = false;

    public static synchronized void append(String entry) {
        buffer.append(entry).append("\n");
    }

    public static synchronized String getContent() {
        if (!buildNumberAdded) {
            String buildNumberHeader = generateBuildNumberHeader();
            buffer.insert(0, buildNumberHeader + "\n");
            buildNumberAdded = true;
        }
        return buffer.toString();
    }

    private static String generateBuildNumberHeader() {
        SimpleDateFormat dateFormat = new SimpleDateFormat("ddMMMyy", Locale.getDefault());
        String formattedDate = dateFormat.format(new Date());
        return "Build: " + formattedDate;
    }

    public static synchronized void clear() {
        buffer.setLength(0);
        buildNumberAdded = false;
    }
}