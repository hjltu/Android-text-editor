package com.example.texteditor.ui.main;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.lifecycle.ViewModelProvider;
import androidx.viewpager2.widget.ViewPager2;

import com.example.texteditor.R;
import com.example.texteditor.data.saf.SAFManager;
import com.example.texteditor.model.Document;
import com.example.texteditor.util.AppLogger;
import com.example.texteditor.ui.editor.DiffEditorView;
import com.example.texteditor.ui.editor.EditorPagerAdapter;

import java.io.IOException;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private DrawerLayout drawerLayout;
    private ViewPager2 viewPager;
    private FrameLayout editorContainer;
    private Button btnModeToggle;
    private TextView tvTitle;
    private TextView tvFileInfo;
    private TextView tvTabCount;
    private LinearLayout openFilesContainer;
    private MainViewModel mainViewModel;
    private SAFManager safManager;
    private LinearLayout menuFontSection;

    private EditorPagerAdapter adapter;
    private boolean showFullPath = false;
    private ActivityResultLauncher<Intent> openDocLauncher;
    private ActivityResultLauncher<Intent> createDocLauncher;
    private ActivityResultLauncher<Intent> openDocLauncherForDiff1;
    private ActivityResultLauncher<Intent> openDocLauncherForDiff2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mainViewModel = new ViewModelProvider(this).get(MainViewModel.class);
        safManager = new SAFManager(this);

        initLaunchers();
        initViews();
        setupListeners();
        observeViewModel();
    }

    private void initLaunchers() {
        openDocLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            result -> {
                if (result.getResultCode() == android.app.Activity.RESULT_OK && result.getData() != null) {
                    Uri uri = result.getData().getData();
                    if (uri != null) handleOpenDocument(uri);
                }
            }
        );

        createDocLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            result -> {
                if (result.getResultCode() == android.app.Activity.RESULT_OK && result.getData() != null) {
                    Uri uri = result.getData().getData();
                    if (uri != null) handleSaveAs(uri);
                }
            }
        );

        openDocLauncherForDiff1 = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            result -> {
                if (result.getResultCode() == android.app.Activity.RESULT_OK && result.getData() != null) {
                    Uri uri = result.getData().getData();
                    if (uri != null) showDiffViewWithFirstFile(uri);
                }
            }
        );

        openDocLauncherForDiff2 = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            result -> {
                if (result.getResultCode() == android.app.Activity.RESULT_OK && result.getData() != null) {
                    Uri uri = result.getData().getData();
                    if (uri != null) showDiffViewWithSecondFile(uri);
                }
            }
        );
    }

    private void initViews() {
        drawerLayout = findViewById(R.id.drawer_layout);
        editorContainer = findViewById(R.id.editor_container);
        viewPager = findViewById(R.id.view_pager_editor);
        btnModeToggle = findViewById(R.id.btn_mode_toggle);
        tvTitle = findViewById(R.id.tv_title);
        tvFileInfo = findViewById(R.id.tv_file_info);
        tvTabCount = findViewById(R.id.tv_tab_count);
        openFilesContainer = findViewById(R.id.menu_open_files);
        menuFontSection = findViewById(R.id.menu_font_section);
    }

    private void setupListeners() {
        ImageButton btnHamburger = findViewById(R.id.btn_hamburger);
        btnHamburger.setOnClickListener(v -> drawerLayout.openDrawer(GravityCompat.START));

        tvTitle.setOnClickListener(v -> {
            showFullPath = !showFullPath;
            updateTitle();
        });

        btnModeToggle.setOnClickListener(v -> toggleMode());

        List<Document> docs = mainViewModel.getOpenDocuments().getValue();
        adapter = new EditorPagerAdapter(this, docs != null ? docs : new java.util.ArrayList<>());
        viewPager.setAdapter(adapter);

        viewPager.registerOnPageChangeCallback(new ViewPager2.OnPageChangeCallback() {
            @Override
            public void onPageSelected(int position) {
                mainViewModel.switchTab(position);
                updateModeButton();
            }
        });

        findViewById(R.id.menu_new).setOnClickListener(v -> {
            handleNewFile();
            drawerLayout.closeDrawer(GravityCompat.START);
        });
        findViewById(R.id.menu_open).setOnClickListener(v -> {
            openDocLauncher.launch(safManager.getOpenDocumentIntent());
            drawerLayout.closeDrawer(GravityCompat.START);
        });
        findViewById(R.id.menu_save).setOnClickListener(v -> {
            handleSave();
            drawerLayout.closeDrawer(GravityCompat.START);
        });
        findViewById(R.id.menu_save_as).setOnClickListener(v -> {
            createDocLauncher.launch(safManager.getCreateDocumentIntent());
            drawerLayout.closeDrawer(GravityCompat.START);
        });
        findViewById(R.id.menu_diff).setOnClickListener(v -> {
            showDiffView();
            drawerLayout.closeDrawer(GravityCompat.START);
        });
        findViewById(R.id.menu_settings).setOnClickListener(v -> {
            boolean visible = menuFontSection.getVisibility() == View.VISIBLE;
            menuFontSection.setVisibility(visible ? View.GONE : View.VISIBLE);
            drawerLayout.closeDrawer(GravityCompat.START);
        });

        android.widget.CheckBox cbLineNumbers = findViewById(R.id.menu_show_line_numbers);
        android.content.SharedPreferences prefs = getSharedPreferences("settings", android.content.Context.MODE_PRIVATE);
        cbLineNumbers.setChecked(prefs.getBoolean("show_line_numbers", true));
        cbLineNumbers.setOnCheckedChangeListener((buttonView, isChecked) -> {
            prefs.edit().putBoolean("show_line_numbers", isChecked).apply();
            updateLineNumbersVisibility(isChecked);
        });
        findViewById(R.id.menu_font_plus).setOnClickListener(v -> {
            mainViewModel.adjustFontSize(1);
            drawerLayout.closeDrawer(GravityCompat.START);
        });
        findViewById(R.id.menu_font_minus).setOnClickListener(v -> {
            mainViewModel.adjustFontSize(-1);
            drawerLayout.closeDrawer(GravityCompat.START);
        });
        findViewById(R.id.menu_about).setOnClickListener(v -> {
            showAboutDialog();
            drawerLayout.closeDrawer(GravityCompat.START);
        });
        findViewById(R.id.menu_quit).setOnClickListener(v -> finish());
    }

    private void showAboutDialog() {
        java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("ddMMMyy", java.util.Locale.getDefault());
        String buildId = sdf.format(new java.util.Date());

        new AlertDialog.Builder(this)
            .setTitle("About SimpleText")
            .setMessage("App Name: " + getString(R.string.app_name) + "\n" +
                         "Author: hjltu\n" +
                         "Version: 1.0 (Code: 1)\n" +
                         "Build ID: " + buildId)
            .setPositiveButton("OK", (dialog, which) -> dialog.dismiss())
            .show();
    }

    private void updateTitle() {
        Document current = mainViewModel.getCurrentDocument();
        if (current != null) {
            // Always show just the filename, regardless of showFullPath setting
            //tvTitle.setText(current.getFilename());
	    String fullPath = current.getFilename();
	    int lastSlashIndex = fullPath.lastIndexOf("/");
            String fileName = fullPath.substring(lastSlashIndex + 1);
            tvTitle.setText(fileName);
        } else {
            tvTitle.setText("SimpleText");
        }
    }

    private void observeViewModel() {
        mainViewModel.getOpenDocuments().observe(this, docs -> {
            updateOpenFilesList(docs);
            if (adapter != null) {
                adapter.setDocuments(docs);
            }
            updateBottomBar();
        });

        mainViewModel.getCurrentTabIndex().observe(this, index -> {
            if (viewPager != null) {
                viewPager.setCurrentItem(index, false);
            }
            updateModeButton();
            updateTitle();
        });
    }

    private void updateBottomBar() {
        List<Document> docs = mainViewModel.getOpenDocuments().getValue();
        int count = docs != null ? docs.size() : 0;
        tvTabCount.setText("Tabs: " + count);
    }

    public void updateFileInfo(int line, int col) {
        tvFileInfo.setText("Line: " + line + ", Col: " + col);
    }

    private void showTabView() {
        editorContainer.removeAllViews();
        viewPager.setVisibility(View.VISIBLE);
        editorContainer.addView(viewPager);
    }

    private Uri diffFirstFileUri = null;
    private Uri diffSecondFileUri = null;
    private boolean waitingForSecondFile = false;

    private void updateLineNumbersVisibility(boolean visible) {
        // Update currently visible editor if it's a single file view
        if (viewPager != null && viewPager.getVisibility() == View.VISIBLE) {
            int currentPos = viewPager.getCurrentItem();
            androidx.fragment.app.Fragment fragment = getSupportFragmentManager().findFragmentByTag("f" + currentPos);
            if (fragment instanceof com.example.texteditor.ui.editor.EditorFragment) {
                ((com.example.texteditor.ui.editor.EditorFragment) fragment).setLineNumbersVisible(visible);
            }
        }

        // Update currently visible diff view
        View diffView = editorContainer.findViewWithTag("diff_view");
        if (diffView == null) {
            // Search for DiffEditorView if tag is missing
            for (int i = 0; i < editorContainer.getChildCount(); i++) {
                View child = editorContainer.getChildAt(i);
                if (child instanceof DiffEditorView) {
                    diffView = child;
                    break;
                }
            }
        }
        if (diffView instanceof DiffEditorView) {
            ((DiffEditorView) diffView).setLineNumbersVisible(visible);
        }
    }

    private void showDiffView() {
        List<Document> docs = mainViewModel.getOpenDocuments().getValue();
        if (docs == null || docs.size() < 2) {
            // If fewer than 2 files, prompt to open files for diff
            showOpenFilesForDiffDialog();
            return;
        }

        // If we already have two files selected (from dialog), use them
        if (diffFirstFileUri != null && diffSecondFileUri != null) {
            setupDiffViewFromUris();
            return;
        }

        // Default behavior: use first two open files
        editorContainer.removeAllViews();
        viewPager.setVisibility(View.GONE);

        DiffEditorView diffView = new DiffEditorView(this);
        diffView.setDocuments(docs.get(0), docs.get(1));
        editorContainer.addView(diffView);
    }

    private void showOpenFilesForDiffDialog() {
        List<Document> docs = mainViewModel.getOpenDocuments().getValue();
        if (docs == null) docs = new java.util.ArrayList<>();

        String[] fileNames = new String[docs.size()];
        for (int i = 0; i < docs.size(); i++) {
            fileNames[i] = docs.get(i).getFilename();
        }

        final List<Document> finalDocs = docs;
        new AlertDialog.Builder(this)
            .setTitle("Select Two Files for Diff")
            .setSingleChoiceItems(fileNames, -1, (dialog, which) -> {
                diffFirstFileUri = finalDocs.get(which).getUri();
                dialog.dismiss();
                // Prompt for second file
                showSecondFileForDiffDialog(finalDocs);
            })
            .setNeutralButton("Cancel", null)
            .show();
    }

    private void showSecondFileForDiffDialog(List<Document> docs) {
        if (docs == null || docs.size() < 2) {
            Toast.makeText(this, "Need at least 2 files", Toast.LENGTH_SHORT).show();
            return;
        }

        String[] fileNames = new String[docs.size()];
        int selectedIndex = -1;
        for (int i = 0; i < docs.size(); i++) {
            fileNames[i] = docs.get(i).getFilename();
            // Don't allow selecting the same file twice
            if (docs.get(i).getUri() != null && docs.get(i).getUri().equals(diffFirstFileUri)) {
                selectedIndex = i;
            }
        }

        final int[] secondSelection = { -1 };
        final List<Document> finalDocs = docs;
        AlertDialog dialog = new AlertDialog.Builder(this)
            .setTitle("Select Second File for Diff")
            .setSingleChoiceItems(fileNames, selectedIndex, (dialog2, which) -> {
                secondSelection[0] = which;
            })
            .setPositiveButton("Diff", (dialog2, which) -> {
                if (secondSelection[0] >= 0) {
                    diffSecondFileUri = finalDocs.get(secondSelection[0]).getUri();
                    setupDiffViewFromUris();
                }
            })
            .setNegativeButton("Cancel", null)
            .create();
        dialog.show();
    }

    private void showDiffViewWithFirstFile(Uri uri) {
        diffFirstFileUri = uri;
        // Automatically prompt for second file
        List<Document> docs = mainViewModel.getOpenDocuments().getValue();
        if (docs != null) {
            showSecondFileForDiffDialog(docs);
        }
    }

    private void showDiffViewWithSecondFile(Uri uri) {
        diffSecondFileUri = uri;
        setupDiffViewFromUris();
    }

    private void setupDiffViewFromUris() {
        if (diffFirstFileUri == null || diffSecondFileUri == null) {
            Toast.makeText(this, "Please select two files", Toast.LENGTH_SHORT).show();
            return;
        }

        editorContainer.removeAllViews();
        viewPager.setVisibility(View.GONE);

        DiffEditorView diffView = new DiffEditorView(this);

        // Get documents by searching through open docs or opening new ones
        Document doc1 = findDocumentByUri(diffFirstFileUri);
        Document doc2 = findDocumentByUri(diffSecondFileUri);

        boolean needsReload = false;
        if (doc1 == null) {
            try {
                String content = safManager.readFile(diffFirstFileUri);
                String filename = safManager.getDisplayNameFromUri(diffFirstFileUri);
                doc1 = new Document(diffFirstFileUri, filename != null ? filename : "File 1", content);
                mainViewModel.addDocument(doc1);
                needsReload = true;
            } catch (IOException e) {
                AppLogger.e("Error reading file: " + e.getMessage());
                Toast.makeText(this, "Error reading file: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                return;
            }
        }

        if (doc2 == null) {
            try {
                String content = safManager.readFile(diffSecondFileUri);
                String filename = safManager.getDisplayNameFromUri(diffSecondFileUri);
                doc2 = new Document(diffSecondFileUri, filename != null ? filename : "File 2", content);
                mainViewModel.addDocument(doc2);
                needsReload = true;
            } catch (IOException e) {
                AppLogger.e("Error reading file: " + e.getMessage());
                Toast.makeText(this, "Error reading file: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                return;
            }
        }

        diffView.setDocuments(doc1, doc2);
        editorContainer.addView(diffView);

        // Reset for next time
        diffFirstFileUri = null;
        diffSecondFileUri = null;
    }

    private Document findDocumentByUri(Uri uri) {
        List<Document> docs = mainViewModel.getOpenDocuments().getValue();
        if (docs == null) return null;
        for (Document doc : docs) {
            if (doc.getUri() != null && doc.getUri().equals(uri)) {
                return doc;
            }
        }
        return null;
    }

    private void handleOpenDocument(Uri uri) {
        AppLogger.i("Opening document: " + uri.toString());
        safManager.persistUriPermission(uri);
        try {
            String content = safManager.readFile(uri);
            String filename = uri.getPath() != null ? uri.getPath() : "Untitled";
            // Use SAFManager to get proper display name (filename only)
            //String displayName = safManager.getDisplayNameFromUri(uri);
            //String filename = displayName != null ? displayName : "Untitled";
            Document doc = new Document(uri, filename, content);
            mainViewModel.addDocument(doc);
            showTabView();
            mainViewModel.updateLogContent();
        } catch (IOException e) {
            AppLogger.e("Error reading file: " + e.getMessage());
            Toast.makeText(this, "Error reading file: " + e.getMessage(), Toast.LENGTH_LONG).show();
            mainViewModel.updateLogContent();
        }
    }

    private void handleNewFile() {
        AppLogger.i("Creating new file");
        String name = mainViewModel.generateUntitledName();
        Document doc = new Document(null, name, "");
        doc.setMode(Document.Mode.READ);
        doc.setDirty(true);
        mainViewModel.addDocument(doc);
        showTabView();
        mainViewModel.updateLogContent();
    }

    private void handleSave() {
        Document current = mainViewModel.getCurrentDocument();
        if (current == null) return;

        if (current.getUri() == null) {
            AppLogger.i("Save requested for untitled file, launching Save As");
            createDocLauncher.launch(safManager.getCreateDocumentIntent());
            return;
        }

        try {
            AppLogger.i("Saving file: " + current.getFilename());
            safManager.writeFile(current.getUri(), current.getContent());
            current.setDirty(false);
            updateOpenFilesList(mainViewModel.getOpenDocuments().getValue());
            Toast.makeText(this, "File saved", Toast.LENGTH_SHORT).show();
            mainViewModel.updateLogContent();
        } catch (IOException e) {
            AppLogger.e("Save failed for " + current.getFilename() + ": " + e.getMessage());
            Toast.makeText(this, "Save failed: " + e.getMessage(), Toast.LENGTH_LONG).show();
            mainViewModel.updateLogContent();
        }
    }

    private void handleSaveAs(Uri uri) {
        Document current = mainViewModel.getCurrentDocument();
        if (current == null) return;

        try {
            AppLogger.i("Saving as: " + uri.toString());
            safManager.writeFile(uri, current.getContent());
            current.setUri(uri);
            // Use DocumentsContract to get the display name instead of full path
            String displayName = safManager.getDisplayNameFromUri(uri);
            current.setFilename(displayName != null ? displayName : uri.getPath());
            current.setDirty(false);
            updateOpenFilesList(mainViewModel.getOpenDocuments().getValue());
            Toast.makeText(this, "Saved as new file", Toast.LENGTH_SHORT).show();
            mainViewModel.updateLogContent();
        } catch (IOException e) {
            AppLogger.e("Save As failed: " + e.getMessage());
            Toast.makeText(this, "Save As failed: " + e.getMessage(), Toast.LENGTH_LONG).show();
            mainViewModel.updateLogContent();
        }
    }

    private void updateOpenFilesList(List<Document> docs) {
        if (openFilesContainer == null || docs == null) return;
        openFilesContainer.removeAllViews();

        for (int i = 0; i < docs.size(); i++) {
            final int index = i;
            Document doc = docs.get(i);

            LinearLayout itemLayout = new LinearLayout(this);
            itemLayout.setOrientation(LinearLayout.HORIZONTAL);
            itemLayout.setGravity(android.view.Gravity.CENTER_VERTICAL);
            itemLayout.setPadding(12, 12, 12, 12);

            TextView tv = new TextView(this);
            String label = doc.toString();
            if (doc.isDirty()) {
                label = label.replace(" ", "*"); // Simple way to ensure dirty mark is clear, though Document.toString already does this.
                // Actually, let's just make sure it's explicitly handled.
            }
            tv.setText(label);
            tv.setTextColor(getResources().getColor(R.color.text_main, null));
            tv.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
            tv.setOnClickListener(v -> {
                mainViewModel.switchTab(index);
                showTabView();
                drawerLayout.closeDrawer(GravityCompat.START);
            });

            TextView btnClose = new TextView(this);
            btnClose.setText("X");
            btnClose.setTextColor(getResources().getColor(R.color.text_main, null));
            btnClose.setTextSize(18);
            btnClose.setPadding(8, 0, 0, 0);
            btnClose.setContentDescription("Close document");
            btnClose.setOnClickListener(v -> {
                if (doc.isDirty()) {
                    // Show dialog to confirm discarding changes
                    new AlertDialog.Builder(MainActivity.this)
                        .setTitle("Unsaved Changes")
                        .setMessage("Save changes to '" + doc.getFilename() + "' before closing?")
                        .setPositiveButton("Save", (dialog, which) -> {
                            handleSave();
                            checkAndCloseDocument(index, doc);
                            dialog.dismiss();
                        })
                        .setNeutralButton("Don't Save", (dialog, which) -> {
                            doc.setDirty(false);
                            AppLogger.i("Closing document without saving: " + doc.getFilename());
                            mainViewModel.closeDocument(index);
                            mainViewModel.updateLogContent();
                            updateOpenFilesList(mainViewModel.getOpenDocuments().getValue());
                            drawerLayout.closeDrawer(GravityCompat.START);
                            dialog.dismiss();
                        })
                        .setNegativeButton("Cancel", null)
                        .show();
                } else {
                    AppLogger.i("Closing document: " + doc.getFilename());
                    mainViewModel.closeDocument(index);
                    mainViewModel.updateLogContent();
                    updateOpenFilesList(mainViewModel.getOpenDocuments().getValue());
                    drawerLayout.closeDrawer(GravityCompat.START);
                }
            });

            itemLayout.addView(tv);
            itemLayout.addView(btnClose);
            openFilesContainer.addView(itemLayout);
        }
    }

    private void checkAndCloseDocument(int index, Document doc) {
        // After save, check if document is no longer dirty and close it
        if (!doc.isDirty()) {
            AppLogger.i("Closing document after save: " + doc.getFilename());
            mainViewModel.closeDocument(index);
            mainViewModel.updateLogContent();
            updateOpenFilesList(mainViewModel.getOpenDocuments().getValue());
            drawerLayout.closeDrawer(GravityCompat.START);
        }
    }

    private void toggleMode() {
        Document current = mainViewModel.getCurrentDocument();
        if (current == null) return;

        boolean wasWriteMode = (current.getMode() == Document.Mode.WRITE);
        current.setMode(wasWriteMode ? Document.Mode.READ : Document.Mode.WRITE);

        if (wasWriteMode && current.isDirty()) {
            handleSave();
        }

        if (wasWriteMode) {
            // Hide keyboard when switching to Read mode
            android.view.inputmethod.InputMethodManager imm = (android.view.inputmethod.InputMethodManager) getSystemService(android.content.Context.INPUT_METHOD_SERVICE);
            if (imm != null) {
                imm.hideSoftInputFromWindow(viewPager.getWindowToken(), 0);
            }
        }

        mainViewModel.refreshDocuments();
        updateModeButton();
    }

    private void updateModeButton() {
        Document current = mainViewModel.getCurrentDocument();
        if (current == null) return;

        if (current.getMode() == Document.Mode.WRITE) {
            btnModeToggle.setText("Edit");
            btnModeToggle.setBackgroundColor(getResources().getColor(R.color.mode_write_red, null));
        } else {
            btnModeToggle.setText("Read");
            btnModeToggle.setBackgroundColor(getResources().getColor(R.color.mode_read_green, null));
        }
    }

    @Override
    public void onBackPressed() {
        if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
            drawerLayout.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }
}
