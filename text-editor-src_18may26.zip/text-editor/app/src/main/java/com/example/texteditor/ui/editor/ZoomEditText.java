package com.example.texteditor.ui.editor;

import android.content.Context;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import androidx.annotation.NonNull;
import androidx.appcompat.widget.AppCompatEditText;

public class ZoomEditText extends AppCompatEditText {

    private static final float MIN_ZOOM = 8f;
    private static final float MAX_ZOOM = 72f;

    private ScaleGestureDetector scaleGestureDetector;
    private float scaleFactor = 1.0f;

    public ZoomEditText(Context context) {
        super(context);
        init(context);
    }

    public ZoomEditText(Context context, AttributeSet attrs) {
        super(context, attrs);
        init(context);
    }

    public ZoomEditText(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init(context);
    }

    private void init(Context context) {
        scaleGestureDetector = new ScaleGestureDetector(context, new ScaleListener());
        // Don't set text size here - let XML or ViewModel initialize it
        // to avoid conflicts with default settings and pinch zoom
    }

    @Override
    public boolean onTouchEvent(@NonNull MotionEvent event) {
        // To prevent ViewPager2 from intercepting touch events during vertical scrolling,
        // we request that the parent does not intercept touch events when the user is interacting.
        if (event.getAction() == MotionEvent.ACTION_DOWN) {
            getParent().requestDisallowInterceptTouchEvent(true);
        }
        super.onTouchEvent(event);
        scaleGestureDetector.onTouchEvent(event);
        return true;
    }

    @Override
    public void onOverScrolled(int scrollX, int scrollY, boolean clampedX, boolean clampedY) {
        // Prevent vertical overscroll bounce/effect
        if (clampedY) {
            return;
        }
        super.onOverScrolled(scrollX, scrollY, clampedX, clampedY);
    }

    private class ScaleListener extends ScaleGestureDetector.SimpleOnScaleGestureListener {
        @Override
        public boolean onScale(ScaleGestureDetector detector) {
            scaleFactor *= detector.getScaleFactor();

            // Clamp text size between 8sp and 72sp
            float newSize = getTextSize() * scaleFactor;
            newSize = Math.max(MIN_ZOOM, Math.min(MAX_ZOOM, newSize));

            updateTextSize(newSize);
            scaleFactor = 1.0f; // Reset scale factor after applying

            return true;
        }
    }

    private void updateTextSize(float size) {
        super.setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, size);
    }
}
