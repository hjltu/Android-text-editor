package com.example.texteditor.ui.editor;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.viewpager2.adapter.FragmentStateAdapter;
import com.example.texteditor.model.Document;
import java.util.List;

public class EditorPagerAdapter extends FragmentStateAdapter {
    private List<Document> documents;

    public EditorPagerAdapter(@NonNull FragmentActivity fragmentActivity, List<Document> documents) {
        super(fragmentActivity);
        this.documents = documents;
    }

    public void setDocuments(List<Document> newDocuments) {
        this.documents = newDocuments;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public Fragment createFragment(int position) {
        // Create a new EditorFragment and pass the index of the document
        return EditorFragment.newInstance(position);
    }

    @Override
    public int getItemCount() {
        return documents != null ? documents.size() : 0;
    }
}
