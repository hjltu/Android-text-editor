package com.example.texteditor.util;

import android.graphics.Color;
import android.text.Spannable;
import android.text.SpannableStringBuilder;
import android.text.style.BackgroundColorSpan;

import java.util.List;
import java.util.ArrayList;

public class DiffUtil {

    /**
     * Simple line-by-line diff algorithm.
     * Compares oldText and newText, marking lines as Added, Removed, or Unchanged.
     */
    public static DiffResult diff(String oldText, String newText) {
        String[] oldArray = oldText.split("\n", -1);
        String[] newArray = newText.split("\n", -1);

        List<DiffResult.Line> diffOld = new ArrayList<>();
        List<DiffResult.Line> diffNew = new ArrayList<>();

        int maxLines = Math.max(oldArray.length, newArray.length);

        for (int i = 0; i < maxLines; i++) {
            String oldLine = i < oldArray.length ? oldArray[i] : null;
            String newLine = i < newArray.length ? newArray[i] : null;

            if (oldLine == null && newLine != null) {
                // Only new line exists (Addition)
                diffNew.add(new DiffResult.Line(newLine, DiffResult.LineType.ADDED));
            } else if (oldLine != null && newLine == null) {
                // Only old line exists (Removal)
                diffOld.add(new DiffResult.Line(oldLine, DiffResult.LineType.REMOVED));
            } else if (oldLine != null && newLine != null && !oldLine.equals(newLine)) {
                // Line changed
                diffOld.add(new DiffResult.Line(oldLine, DiffResult.LineType.REMOVED));
                diffNew.add(new DiffResult.Line(newLine, DiffResult.LineType.ADDED));
            } else if (oldLine != null && newLine != null) {
                // Unchanged
                diffOld.add(new DiffResult.Line(oldLine, DiffResult.LineType.UNCHANGED));
                diffNew.add(new DiffResult.Line(newLine, DiffResult.LineType.UNCHANGED));
            }
        }

        return new DiffResult(diffOld, diffNew);
    }

    /**
     * Applies background colors to a text string based on diff lines.
     */
    public static SpannableStringBuilder applyHighlighting(List<DiffResult.Line> lines) {
        SpannableStringBuilder sb = new SpannableStringBuilder();

        int colorAdd = Color.parseColor("#EEFBEE"); // Light Green
        int colorRemove = Color.parseColor("#FEEFEF"); // Light Red

        for (DiffResult.Line line : lines) {
            String displayLine = line.content + "\n";
            int start = sb.length();
            sb.append(displayLine);
            int end = sb.length();

            if (line.type == DiffResult.LineType.ADDED) {
                sb.setSpan(new BackgroundColorSpan(colorAdd), start, end, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
            } else if (line.type == DiffResult.LineType.REMOVED) {
                sb.setSpan(new BackgroundColorSpan(colorRemove), start, end, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
            }
        }

        return sb;
    }
}
