package com.example.texteditor.util;

import android.util.Log;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class AppLogger {
    private static final String TAG = "SimpleTextEditor";
    private static final SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());

    public enum Level {
        INFO, DEBUG, WARN, ERROR
    }

    public static void log(Level level, String message) {
        String timestamp = dateFormat.format(new Date());
        String logEntry = String.format("[%s] [%s] %s", timestamp, level.name(), message);

        // Log to Android Logcat
        switch (level) {
            case INFO: Log.i(TAG, message); break;
            case DEBUG: Log.d(TAG, message); break;
            case WARN: Log.w(TAG, message); break;
            case ERROR: Log.e(TAG, message); break;
        }

        // In a real Android app, writing to a file requires context/SAF.
        // For the purpose of the `log_data.txt` requirement, we will maintain
        // an internal buffer that can be retrieved by the Document system.
        LogBuffer.append(logEntry);
    }

    public static void i(String msg) { log(Level.INFO, msg); }
    public static void d(String msg) { log(Level.DEBUG, msg); }
    public static void w(String msg) { log(Level.WARN, msg); }
    public static void e(String msg) { log(Level.ERROR, msg); }
}
