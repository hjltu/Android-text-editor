package com.example.texteditor.data.saf;

import android.content.Context;
import android.content.Intent;
import android.content.ContentResolver;
import android.net.Uri;
import android.database.Cursor;
import android.os.Build;
import android.provider.DocumentsContract;
import android.util.Log;
import java.io.*;
import java.nio.charset.StandardCharsets;

public class SAFManager {
    private static final String TAG = "SAFManager";
    private final Context context;
    private final ContentResolver contentResolver;

    public SAFManager(Context context) {
        this.context = context;
        this.contentResolver = context.getContentResolver();
    }

    /**
     * Creates an intent for opening a text document.
     */
    public Intent getOpenDocumentIntent() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("text/plain");
        return intent;
    }

    /**
     * Persists the URI permission so the app can access the file later.
     */
    public boolean persistUriPermission(Uri uri) {
        try {
            int flags = Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION;
            contentResolver.takePersistableUriPermission(uri, flags);
            return true;
        } catch (SecurityException e) {
            Log.e(TAG, "Failed to persist URI permission: " + e.getMessage());
            return false;
        }
    }

    /**
     * Reads the content of a URI into a String.
     */
    public String readFile(Uri uri) throws IOException {
        try (InputStream inputStream = contentResolver.openInputStream(uri);
             BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream, StandardCharsets.UTF_8))) {

            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                sb.append(line).append("\n");
            }
            return sb.toString();
        }
    }

    /**
     * Writes a string to a URI using an atomic strategy.
     * Writes to a temporary file first, then copies to the target.
     */
    public void writeFile(Uri uri, String content) throws IOException {
        // 1. Write to temporary file in internal cache
        File tempFile = File.createTempFile("saf_temp", ".txt", context.getCacheDir());
        try (FileOutputStream fos = new FileOutputStream(tempFile);
             OutputStreamWriter osw = new OutputStreamWriter(fos, StandardCharsets.UTF_8)) {
            osw.write(content);
            osw.flush();
        }

        // 2. Copy temp file to the SAF URI
        try (InputStream is = new FileInputStream(tempFile);
             OutputStream os = contentResolver.openOutputStream(uri, "wt")) {

            byte[] buffer = new byte[8192];
            int bytesRead;
            while ((bytesRead = is.read(buffer)) != -1) {
                os.write(buffer, 0, bytesRead);
            }
        } finally {
            tempFile.delete();
        }
    }

    /**
     * Creates an intent for creating a new document (Save As).
     */
    public Intent getCreateDocumentIntent() {
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("text/plain");
        return intent;
    }

    /**
     * Gets the display name from a URI using DocumentsContract.
     * Returns the filename to show in the UI instead of full path.
     */
    public String getDisplayNameFromUri(Uri uri) {
        if (uri == null) return null;

        try (Cursor cursor = contentResolver.query(uri, new String[]{DocumentsContract.Document.COLUMN_DISPLAY_NAME}, null, null, null)) {
            if (cursor != null && cursor.moveToFirst()) {
                int columnIndex = cursor.getColumnIndex(DocumentsContract.Document.COLUMN_DISPLAY_NAME);
                if (columnIndex != -1) {
                    return cursor.getString(columnIndex);
                }
            }
        } catch (Exception e) {
            Log.e(TAG, "Failed to get display name from URI: " + e.getMessage());
        }
        return null;
    }
}
