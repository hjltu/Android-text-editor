package com.example.texteditor.model;

import android.net.Uri;

public class Document {
    public enum Mode { READ, WRITE }

    private Uri uri;
    private String filename;
    private String content;
    private boolean isDirty = false;
    private Mode mode = Mode.READ;

    public Document(Uri uri, String filename, String content) {
        this.uri = uri;
        this.filename = filename;
        this.content = content;
    }

    public Uri getUri() { return uri; }
    public void setUri(Uri uri) { this.uri = uri; }

    public String getFilename() { return filename; }
    public void setFilename(String filename) { this.filename = filename; }

    public String getContent() { return content; }
    public void setContent(String content) { this.content = content; }

    public boolean isDirty() { return isDirty; }
    public void setDirty(boolean dirty) { this.isDirty = dirty; }

    public Mode getMode() { return mode; }
    public void setMode(Mode mode) { this.mode = mode; }

    @Override
    public String toString() {
        String modeChar = (mode == Mode.READ) ? "r" : "w";
        String dirtyChar = isDirty ? "*" : " ";
        return modeChar + dirtyChar + " " + filename;
    }
}
