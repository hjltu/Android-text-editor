package com.example.texteditor.util;

import java.util.ArrayList;
import java.util.List;

public class DiffResult {
    public enum LineType { UNCHANGED, ADDED, REMOVED }

    public static class Line {
        public final String content;
        public final LineType type;

        public Line(String content, LineType type) {
            this.content = content;
            this.type = type;
        }
    }

    public final List<Line> oldLines;
    public final List<Line> newLines;

    public DiffResult(List<Line> oldLines, List<Line> newLines) {
        this.oldLines = oldLines;
        this.newLines = newLines;
    }
}
